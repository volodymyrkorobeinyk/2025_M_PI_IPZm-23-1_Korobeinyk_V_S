import { GroupState } from './groups/groups.state';
import { TaskState } from './tasks/tasks.state';
import { groupsFeature } from './groups/groups.feature';
import { tasksFeature } from './tasks/tasks.feature';

export interface AppState {
  groups: GroupState;
  tasks: TaskState;
}

export const appState = {
  [groupsFeature.name]: groupsFeature.reducer,
  [tasksFeature.name]: tasksFeature.reducer,
};
