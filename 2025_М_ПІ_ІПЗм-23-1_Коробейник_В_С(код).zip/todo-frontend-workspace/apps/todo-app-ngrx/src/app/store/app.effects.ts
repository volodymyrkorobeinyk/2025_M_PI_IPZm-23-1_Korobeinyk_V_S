import {GroupsEffects} from "./groups/groups.effects";
import {TasksEffects} from "./tasks/tasks.effects";

export const appEffects = [
  GroupsEffects,
  TasksEffects
];
