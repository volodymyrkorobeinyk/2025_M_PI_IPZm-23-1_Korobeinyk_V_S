import { createFeatureSelector, createSelector } from '@ngrx/store';
import { TaskState } from './tasks.state';

export const TASKS_FEATURE_KEY = 'tasks';

export const selectTasksState =
  createFeatureSelector<TaskState>(TASKS_FEATURE_KEY);

export const selectAllTasks = createSelector(
  selectTasksState,
  (state) => state.tasks
);

export const errorSelector = createSelector(
  selectTasksState,
  (state) => state.error
);

export const selectIsLoading = createSelector(
  selectTasksState,
  (state) => state.isLoading
);

export const selectFilterStatus = createSelector(
  selectTasksState,
  (state) => state.filterStatus
);

export const selectManageFormTaskStatus = createSelector(
  selectTasksState,
  (state) => state.isManageTaskModalOpen
);

export const selectEditableTask = createSelector(
  selectTasksState,
  (state) => state.editableTask
);
