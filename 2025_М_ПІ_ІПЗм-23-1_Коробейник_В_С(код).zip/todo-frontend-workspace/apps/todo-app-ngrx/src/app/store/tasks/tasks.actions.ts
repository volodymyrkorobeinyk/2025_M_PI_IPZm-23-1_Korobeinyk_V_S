import { createAction, props } from '@ngrx/store';
import {CreateTaskRequestDto, TaskDto, TaskFilterType, UpdateTaskRequestDto} from '@todo-frontend-workspace/shared';

export enum TasksActionTypes {
  GET_TASKS = '[Tasks] Get Tasks',
  GET_TASKS_SUCCESS = '[Tasks] Get Tasks Success',
  GET_TASKS_FAILURE = '[Tasks] Get Tasks Failure',

  CHANGE_FILTER_STATUS = '[Tasks] Filter Tasks',

  CREATE_TASK = '[Tasks] Create Task',
  CREATE_TASK_SUCCESS = '[Tasks] Create Task Success',
  CREATE_TASK_FAILURE = '[Tasks] Create Task Failure',

  UPDATE_TASK = '[Tasks] Update Task',
  UPDATE_TASK_SUCCESS = '[Tasks] Update Task Success',
  UPDATE_TASK_FAILURE = '[Tasks] Update Task Failure',

  DELETE_TASK = '[Tasks] Delete Task',
  DELETE_TASK_SUCCESS = '[Tasks] Delete Task Success',
  DELETE_TASK_FAILURE = '[Tasks] Delete Task Failure',

  TOGGLE_COMPLETION_STATUS = '[Tasks] Toggle Completion Task Status',
  TOGGLE_COMPLETION_SUCCESS = '[Tasks] Toggle Completion Task Status Success',
  TOGGLE_COMPLETION_FAILURE = '[Tasks] Toggle Completion Task Status Failure',

  OPEN_MANAGE_TASK_MODAL = '[Tasks] Open Manage Task Modal',
  CLOSE_MANAGE_TASK_MODAL = '[Tasks] Close Manage Task Modal',
  CHANGE_EDITABLE_TASK = '[Tasks] Change Editable Task',
}

// Get Tasks
export const getTasks = createAction(
  TasksActionTypes.GET_TASKS,
  props<{ groupId: string, filter: TaskFilterType }>()
);
export const getTasksSuccess = createAction(
  TasksActionTypes.GET_TASKS_SUCCESS,
  props<{ tasks: TaskDto[] }>()
);
export const getTasksFailure = createAction(
  TasksActionTypes.GET_TASKS_FAILURE,
  props<{ error: string }>()
);

// Filter Tasks
export const changeFilterStatus = createAction(
  TasksActionTypes.CHANGE_FILTER_STATUS,
  props<{ filterType: TaskFilterType }>()
);

// Create Task
export const createTask = createAction(
  TasksActionTypes.CREATE_TASK, props<{ task: CreateTaskRequestDto }>()
);

export const createTaskSuccess = createAction(
  TasksActionTypes.CREATE_TASK_SUCCESS, props<{ task: TaskDto }>()
);

export const createTaskFailure = createAction(
  TasksActionTypes.CREATE_TASK_FAILURE, props<{ error: string }>()
);

// Update Task
export const updateTask = createAction(
  TasksActionTypes.UPDATE_TASK, props<{oldGroupId: string, id: string, task: UpdateTaskRequestDto }>()
);

export const updateTaskSuccess = createAction(
  TasksActionTypes.UPDATE_TASK_SUCCESS, props<{ oldGroupId: string, task: TaskDto }>()
);

export const updateTaskFailure = createAction(
  TasksActionTypes.UPDATE_TASK_FAILURE, props<{ error: string }>()
);

// Delete Task
export const deleteTask = createAction(
  TasksActionTypes.DELETE_TASK, props<{groupId: string, id: string }>()
);

export const deleteTaskSuccess = createAction(
  TasksActionTypes.DELETE_TASK_SUCCESS, props<{ id: string }>()
);

export const deleteTaskFailure = createAction(
  TasksActionTypes.DELETE_TASK_FAILURE, props<{ error: string }>()
);

// Toggle Completion Status
export const toggleCompletion = createAction(
  TasksActionTypes.TOGGLE_COMPLETION_STATUS, props<{ id: string }>()
);

export const toggleCompletionSuccess = createAction(
  TasksActionTypes.TOGGLE_COMPLETION_SUCCESS, props<{ task: TaskDto }>()
);

export const toggleCompletionFailure = createAction(
  TasksActionTypes.TOGGLE_COMPLETION_FAILURE, props<{ error: string }>()
);

// Manage Task Modal
export const openManageTaskModal = createAction(
  TasksActionTypes.OPEN_MANAGE_TASK_MODAL
);

export const closeManageTaskModal = createAction(
  TasksActionTypes.CLOSE_MANAGE_TASK_MODAL
);

export const changeEditableTask = createAction(
  TasksActionTypes.CHANGE_EDITABLE_TASK,
  props<{ task: TaskDto | null }>()
);
