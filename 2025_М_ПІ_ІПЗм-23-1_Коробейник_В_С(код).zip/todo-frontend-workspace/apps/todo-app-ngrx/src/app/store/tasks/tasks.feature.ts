import { createFeature } from '@ngrx/store';
import { TASKS_FEATURE_KEY } from './tasks.selectors';
import { tasksReducer } from './tasks.reducer';

export const tasksFeature = createFeature({
  name: TASKS_FEATURE_KEY,
  reducer: tasksReducer,
});
