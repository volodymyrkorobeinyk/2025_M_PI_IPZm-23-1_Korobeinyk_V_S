import { inject, Injectable } from '@angular/core';
import { Actions, createEffect, ofType } from '@ngrx/effects';
import { TasksApiService } from '@todo-frontend-workspace/shared';
import {catchError, map, mergeMap, of, switchMap} from 'rxjs';
import * as TasksActions from './tasks.actions';
import * as GroupsActions from '../groups/groups.actions';

@Injectable({
  providedIn: 'root',
})
export class TasksEffects {
  private readonly actions$ = inject(Actions);
  private readonly tasksApiService = inject(TasksApiService);

  public getTasks$ = createEffect(() =>
    this.actions$.pipe(
      ofType(TasksActions.getTasks),
      switchMap(({ groupId, filter }) =>
        this.tasksApiService.getAllByGroupId(groupId, filter).pipe(
          map((tasks) => TasksActions.getTasksSuccess({ tasks })),
          catchError((error) => of(TasksActions.getTasksFailure({ error })))
        )
      )
    )
  );

  public createTask$ = createEffect(() =>
    this.actions$.pipe(
      ofType(TasksActions.createTask),
      switchMap(({ task }) =>
        this.tasksApiService.create(task).pipe(
          mergeMap((createdTask) => [
            TasksActions.createTaskSuccess({ task: createdTask }),
            GroupsActions.incrementGroupTaskCount({ groupId: createdTask.groupId })
          ]),
          catchError((error) => of(TasksActions.createTaskFailure({ error })))
        )
      )
    )
  );

  public updateTask$ = createEffect(() =>
    this.actions$.pipe(
      ofType(TasksActions.updateTask),
      switchMap(({ oldGroupId, id, task }) =>
        this.tasksApiService.update(id, task).pipe(
          mergeMap((updatedTask) => {
            if (oldGroupId !== updatedTask.groupId) {
              return [
                TasksActions.updateTaskSuccess({ oldGroupId, task: updatedTask }),
                GroupsActions.decrementGroupTaskCount({ groupId: oldGroupId }),
                GroupsActions.incrementGroupTaskCount({ groupId: updatedTask.groupId })
              ];
            }
            return [TasksActions.updateTaskSuccess({ oldGroupId, task: updatedTask })];
          }),
          catchError((error) => of(TasksActions.updateTaskFailure({ error })))
        )
      )
    )
  );

  public deleteTask$ = createEffect(() =>
    this.actions$.pipe(
      ofType(TasksActions.deleteTask),
      switchMap(({ groupId, id }) =>
        this.tasksApiService.delete(id).pipe(
          mergeMap(() => [
            TasksActions.deleteTaskSuccess({ id }),
            GroupsActions.decrementGroupTaskCount({ groupId: groupId })
          ]),
          catchError((error) => of(TasksActions.deleteTaskFailure({ error })))
        )
      )
    )
  );

  public toggleCompletion$ = createEffect(() =>
    this.actions$.pipe(
      ofType(TasksActions.toggleCompletion),
      switchMap(({ id }) =>
        this.tasksApiService.toggleCompletion(id).pipe(
          map((updatedTask) => TasksActions.toggleCompletionSuccess({ task: updatedTask })),
          catchError((error) => of(TasksActions.toggleCompletionFailure({ error })))
        )
      )
    )
  );
}
