import { createReducer, on } from '@ngrx/store';
import { initialState, TaskState } from './tasks.state';
import * as TasksActions from './tasks.actions';

const failureRequest = (state: TaskState, action: any) =>
  ({...state, isLoading: false, error: action.error});

const processRequest = (state: TaskState) =>
  ({ ...state, isLoading: true });

export const tasksReducer = createReducer(
  initialState,
  // Get Tasks
  on(TasksActions.getTasks, processRequest),
  on(TasksActions.getTasksSuccess, (state, { tasks }) => {
    return {...state, tasks, isLoading: false, error: null,};
  }),
  // Filter Tasks
  on(TasksActions.getTasksFailure, failureRequest),
  on(TasksActions.changeFilterStatus, (state, action) => ({
    ...state, filterStatus: action.filterType
  })),
  // Create Task
  on(TasksActions.createTask, processRequest),
  on(TasksActions.createTaskSuccess, (state, action) => {
    const tasks = [...state.tasks, action.task];
    return {...state, tasks, isLoading: false, error: null};
  }),
  on(TasksActions.createTaskFailure, failureRequest),
  // Update Task
  on(TasksActions.updateTask, processRequest),
  on(TasksActions.updateTaskSuccess, (state, action) => {
    let tasks = state.tasks.map((task) => task.id === action.task.id ? action.task : task);
    if (action.oldGroupId !== action.task.groupId) {
      tasks = tasks.filter((task) => task.id !== action.task.id);
    }
    return {...state, tasks, isLoading: false, error: null};
  }),
  on(TasksActions.updateTaskFailure, failureRequest),
  // Delete Task
  on(TasksActions.deleteTask, processRequest),
  on(TasksActions.deleteTaskSuccess, (state, action) => {
    const tasks = state.tasks.filter((task) => task.id !== action.id);
    return {...state, tasks, isLoading: false, error: null,};
  }),
  on(TasksActions.deleteTaskFailure, failureRequest),
  // Toggle Completion Status
  on(TasksActions.toggleCompletion, processRequest),
  on(TasksActions.toggleCompletionSuccess, (state, action) => {
    const tasks = state.tasks.map((task) => task.id === action.task.id ? action.task : task);
    return {...state, tasks, isLoading: false, error: null};
  }),
  on(TasksActions.toggleCompletionFailure, failureRequest),
  // Manage Task Modal
  on(TasksActions.openManageTaskModal, (state) => ({
    ...state,
    isManageTaskModalOpen: true,
  })),
  on(TasksActions.closeManageTaskModal, (state) => ({
    ...state,
    isManageTaskModalOpen: false,
  })),
  on(TasksActions.changeEditableTask, (state, action) => ({
    ...state,
    editableTask: action.task,
  }))
);
