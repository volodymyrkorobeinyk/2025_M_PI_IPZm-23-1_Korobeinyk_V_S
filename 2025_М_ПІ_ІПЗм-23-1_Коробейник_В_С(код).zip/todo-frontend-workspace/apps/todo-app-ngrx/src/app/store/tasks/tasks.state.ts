import {TaskDto, TaskFilterType} from '@todo-frontend-workspace/shared';


export interface TaskState {
  tasks: TaskDto[];
  filterStatus: TaskFilterType
  isManageTaskModalOpen: boolean;
  editableTask: TaskDto | null;
  isLoading: boolean;
  error: string | null;
}

export const initialState: TaskState = {
  tasks: [],
  filterStatus: TaskFilterType.ALL,
  isManageTaskModalOpen: false,
  editableTask: null,
  isLoading: false,
  error: null,
};
