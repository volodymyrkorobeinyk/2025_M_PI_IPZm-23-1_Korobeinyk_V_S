import { GroupDto } from "@todo-frontend-workspace/shared";

export interface GroupState {
  groups: GroupDto[] | null;
  searchQuery: string;
  selectedGroup: GroupDto | null;
  isManageGroupModalOpen: boolean;
  editableGroup: GroupDto | null;
  isLoading: boolean;
  error: string | null;
}

export const initialState: GroupState = {
  groups: null,
  searchQuery: '',
  selectedGroup: null,
  isManageGroupModalOpen: false,
  editableGroup: null,
  isLoading: false,
  error: null
};
