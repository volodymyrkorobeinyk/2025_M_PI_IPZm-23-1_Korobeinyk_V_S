import { createReducer, on } from '@ngrx/store';
import {GroupState, initialState} from './groups.state';
import * as GroupsActions from './groups.actions';

const failureRequest = (state: GroupState, action: any) =>
  ({ ...state, isLoading: false, error: action.error });

const processRequest = (state: GroupState) =>
  ({ ...state, isLoading: true });

export const groupReducer = createReducer(
  initialState,
  // Get Groups
  on(GroupsActions.getGroups, processRequest),
  on(GroupsActions.getGroupsSuccess, (state, action) => ({
    ...state,
    isLoading: false,
    groups: action.groups,
  })),
  on(GroupsActions.getGroupsFailure, failureRequest),
  // Search Groups
  on(GroupsActions.searchGroups, (state, action) => {
    return {
      ...state,
      searchQuery: action.query,
      isLoading: true,
    };
  }),
  on(GroupsActions.searchGroupsSuccess, (state, action) => ({
    ...state,
    isLoading: false,
    groups: action.groups,
  })),
  on(GroupsActions.searchGroupsFailure, failureRequest),
  // Select Group
  on(GroupsActions.selectGroup, (state, action) => {
    const { groups, selectedGroup } = state;
    if (!groups) return state;

    if (selectedGroup && selectedGroup.id === action.id) {
      return {...state, selectedGroup: null};
    }

    const potentialSelectedGroup = groups
      .find((group) => group.id === action.id);

    return {...state, selectedGroup: potentialSelectedGroup || null};
  }),
  // Create Group
  on(GroupsActions.createGroup, processRequest),
  on(GroupsActions.createGroupSuccess, (state, action) => {
    const { groups } = state;
    if (!groups) return state;
    return {
      ...state,
      isLoading: false,
      groups: [...groups, action.group],
    };
  }),
  on(GroupsActions.createGroupFailure, failureRequest),
  // Update Group
  on(GroupsActions.updateGroup, processRequest),
  on(GroupsActions.updateGroupSuccess, (state, action) => {
    const { groups } = state;
    if (!groups) return state;

    const newGroups = groups.map((group) =>
      group.id === action.group.id ? action.group : group
    );

    return {
      ...state,
      isLoading: false,
      groups: newGroups,
    };
  }),
  on(GroupsActions.updateGroupFailure, failureRequest),
  // Delete Group
  on(GroupsActions.deleteGroup, processRequest),
  on(GroupsActions.deleteGroupSuccess, (state, action) => {
    const { groups, selectedGroup } = state;
    if (!groups) return state;

    const newGroups = groups.filter((group) => group.id !== action.id);

    return {
      ...state,
      isLoading: false,
      groups: newGroups,
      selectedGroup: selectedGroup && selectedGroup.id === action.id ? null : selectedGroup,
    };
  }),
  on(GroupsActions.deleteGroupFailure, failureRequest),
  // Manage Group Modal
  on(GroupsActions.openManageGroupModal, (state) => ({
    ...state,
    isManageGroupModalOpen: true,
  })),
  on(GroupsActions.closeManageGroupModal, (state) => ({
    ...state,
    isManageGroupModalOpen: false,
  })),
  on(GroupsActions.changeEditableGroup, (state, action) => ({
    ...state,
    editableGroup: action.group,
  })),
  // Group Task Count
  on(GroupsActions.incrementGroupTaskCount, (state, action) => {
    const { groups } = state;
    if (!groups) return state;

    const newGroups = groups.map((group) =>
      group.id === action.groupId
        ? { ...group, taskCount: Number(group.taskCount) + 1 }
        : group
    );

    return {
      ...state,
      groups: newGroups,
    };
  }),
  on(GroupsActions.decrementGroupTaskCount, (state, action) => {
    const { groups } = state;
    if (!groups) return state;

    const newGroups = groups.map((group) =>
      group.id === action.groupId
        ? { ...group, taskCount: Number(group.taskCount) - 1 }
        : group
    );

    return {
      ...state,
      groups: newGroups,
    };
  }),

);
