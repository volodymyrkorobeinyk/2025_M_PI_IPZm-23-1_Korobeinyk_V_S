import {createFeatureSelector, createSelector} from "@ngrx/store";
import {GroupState} from "./groups.state";

export const GROUPS_FEATURE_KEY = 'groups';

export const selectGroupsState = createFeatureSelector<GroupState>(GROUPS_FEATURE_KEY);

export const selectAllGroups = createSelector(
  selectGroupsState, (state) => state.groups
);

export const selectSelectedGroup = createSelector(
  selectGroupsState, (state) => state.selectedGroup
);

export const errorSelector = createSelector(
  selectGroupsState, (state) => state.error
);

export const selectManageFormGroupStatus = createSelector(
  selectGroupsState, (state) => state.isManageGroupModalOpen
);

export const selectEditableGroup = createSelector(
  selectGroupsState, (state) => state.editableGroup
);

export const selectGroupsLoading = createSelector(
  selectGroupsState, (state) => state.isLoading
);


