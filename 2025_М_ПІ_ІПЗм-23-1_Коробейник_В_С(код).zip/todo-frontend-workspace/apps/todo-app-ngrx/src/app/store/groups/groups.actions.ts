import {createAction, props} from "@ngrx/store";
import {CreateGroupRequestDto, GroupDto, UpdateGroupRequestDto} from "@todo-frontend-workspace/shared";

export enum GroupsActionTypes {
  GET_GROUPS = '[Groups] Get Groups',
  GET_GROUPS_SUCCESS = '[Groups] Get Groups Success',
  GET_GROUPS_FAILURE = '[Groups] Get Groups Failure',

  SEARCH_GROUPS = '[Groups] Search Groups',
  SEARCH_GROUPS_SUCCESS = '[Groups] Search Groups Success',
  SEARCH_GROUPS_FAILURE = '[Groups] Search Groups Failure',

  SELECT_GROUP = '[Groups] Select Group',

  CREATE_GROUP = '[Groups] Create Group',
  CREATE_GROUP_SUCCESS = '[Groups] Create Group Success',
  CREATE_GROUP_FAILURE = '[Groups] Create Group Failure',

  UPDATE_GROUP = '[Groups] Update Group',
  UPDATE_GROUP_SUCCESS = '[Groups] Update Group Success',
  UPDATE_GROUP_FAILURE = '[Groups] Update Group Failure',

  DELETE_GROUP = '[Groups] Delete Group',
  DELETE_GROUP_SUCCESS = '[Groups] Delete Group Success',
  DELETE_GROUP_FAILURE = '[Groups] Delete Group Failure',

  OPEN_MANAGE_GROUP_MODAL = '[Groups] Open Manage Group Modal',
  CLOSE_MANAGE_GROUP_MODAL = '[Groups] Close Manage Group Modal',
  CHANGE_EDITABLE_GROUP = '[Groups] Change Editable Group',

  INCREMENT_GROUP_TASK_COUNT = '[Groups] Increment Task Count',
  DECREMENT_GROUP_TASK_COUNT = '[Groups] Decrement Task Count',
}

// Get Groups
export const getGroups = createAction(
  GroupsActionTypes.GET_GROUPS
);

export const getGroupsSuccess = createAction(
  GroupsActionTypes.GET_GROUPS_SUCCESS, props<{ groups: GroupDto[] }>()
);

export const getGroupsFailure = createAction(
  GroupsActionTypes.GET_GROUPS_FAILURE, props<{ error: string }>()
);

// Select Group
export const selectGroup = createAction(
  GroupsActionTypes.SELECT_GROUP, props<{ id: string }>()
);

// Search Groups
export const searchGroups = createAction(
  GroupsActionTypes.SEARCH_GROUPS, props<{ query: string }>()
);

export const searchGroupsSuccess = createAction(
  GroupsActionTypes.SEARCH_GROUPS_SUCCESS, props<{ groups: GroupDto[] }>()
);

export const searchGroupsFailure = createAction(
  GroupsActionTypes.SEARCH_GROUPS_FAILURE, props<{ error: string }>()
);

// Create Groups
export const createGroup = createAction(
  GroupsActionTypes.CREATE_GROUP, props<CreateGroupRequestDto>()
);

export const createGroupSuccess = createAction(
  GroupsActionTypes.CREATE_GROUP_SUCCESS, props<{ group: GroupDto }>()
);

export const createGroupFailure = createAction(
  GroupsActionTypes.CREATE_GROUP_FAILURE, props<{ error: string }>()
);

// Update Groups
export const updateGroup = createAction(
  GroupsActionTypes.UPDATE_GROUP, props<{ id: string, group: UpdateGroupRequestDto }>()
);

export const updateGroupSuccess = createAction(
  GroupsActionTypes.UPDATE_GROUP_SUCCESS, props<{ group: GroupDto }>()
);

export const updateGroupFailure = createAction(
  GroupsActionTypes.UPDATE_GROUP_FAILURE, props<{ error: string }>()
);

// Delete Groups
export const deleteGroup = createAction(
  GroupsActionTypes.DELETE_GROUP, props<{ id: string }>()
);

export const deleteGroupSuccess = createAction(
  GroupsActionTypes.DELETE_GROUP_SUCCESS, props<{ id: string }>()
);

export const deleteGroupFailure = createAction(
  GroupsActionTypes.DELETE_GROUP_FAILURE, props<{ error: string }>()
);

// Manage Group Modal
export const openManageGroupModal = createAction(
  GroupsActionTypes.OPEN_MANAGE_GROUP_MODAL
);

export const closeManageGroupModal = createAction(
  GroupsActionTypes.CLOSE_MANAGE_GROUP_MODAL
);

export const changeEditableGroup = createAction(
  GroupsActionTypes.CHANGE_EDITABLE_GROUP, props<{ group: GroupDto | null }>()
);

// Group Task Count
export const incrementGroupTaskCount = createAction(
  GroupsActionTypes.INCREMENT_GROUP_TASK_COUNT,
  props<{ groupId: string }>()
);

export const decrementGroupTaskCount = createAction(
  GroupsActionTypes.DECREMENT_GROUP_TASK_COUNT,
  props<{ groupId: string }>()
);
