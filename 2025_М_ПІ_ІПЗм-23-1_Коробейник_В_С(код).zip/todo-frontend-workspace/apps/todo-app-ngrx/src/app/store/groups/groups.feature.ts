import {createFeature} from "@ngrx/store";
import {GROUPS_FEATURE_KEY} from "./groups.selectors";
import {groupReducer} from "./groups.reducer";

export const groupsFeature = createFeature({
  name: GROUPS_FEATURE_KEY,
  reducer: groupReducer
});
