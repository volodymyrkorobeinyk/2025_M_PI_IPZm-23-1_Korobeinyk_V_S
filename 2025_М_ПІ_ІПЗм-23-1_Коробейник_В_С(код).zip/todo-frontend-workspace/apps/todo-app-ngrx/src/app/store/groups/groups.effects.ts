import { inject, Injectable } from '@angular/core';
import { Actions, createEffect, ofType } from '@ngrx/effects';
import * as GroupsActions from './groups.actions';
import { catchError, map, mergeMap, of } from 'rxjs';
import { GroupsApiService } from '@todo-frontend-workspace/shared';

@Injectable({
  providedIn: 'root',
})
export class GroupsEffects {
  private readonly actions$ = inject(Actions);
  private readonly groupsApiService = inject(GroupsApiService);

  public getGroups$ = createEffect(() =>
    this.actions$.pipe(
      ofType(GroupsActions.getGroups),
      mergeMap(() =>
        this.groupsApiService.getAll().pipe(
          map((groups) => GroupsActions.getGroupsSuccess({ groups })),
          catchError((error) => of(GroupsActions.getGroupsFailure({ error })))
        )
      )
    )
  );

  public searchGroups$ = createEffect(() =>
    this.actions$.pipe(
      ofType(GroupsActions.searchGroups),
      mergeMap(({ query }) =>
        this.groupsApiService.searchByName(query).pipe(
          map((groups) => GroupsActions.searchGroupsSuccess({ groups })),
          catchError((error) => of(GroupsActions.searchGroupsFailure({ error })))
        )
      )
    )
  );

  public createGroup$ = createEffect(() =>
    this.actions$.pipe(
      ofType(GroupsActions.createGroup),
      mergeMap(({ name }) =>
        this.groupsApiService.create({ name }).pipe(
          map((group) => {
            return GroupsActions.createGroupSuccess({group});
          }),
          catchError((error) => of(GroupsActions.createGroupFailure({ error })))
        )
      )
    )
  );

  public updateGroup$ = createEffect(() =>
    this.actions$.pipe(
      ofType(GroupsActions.updateGroup),
      mergeMap(({ id, group }) =>
        this.groupsApiService.update(id, group).pipe(
          map((group) => GroupsActions.updateGroupSuccess({ group })),
          catchError((error) => of(GroupsActions.updateGroupFailure({ error })))
        )
      )
    )
  );

  public deleteGroup$ = createEffect(() =>
    this.actions$.pipe(
      ofType(GroupsActions.deleteGroup),
      mergeMap(({ id }) =>
        this.groupsApiService.delete(id).pipe(
          map(() => GroupsActions.deleteGroupSuccess({ id })),
          catchError((error) => of(GroupsActions.deleteGroupFailure({ error })))
        )
      )
    )
  );
}
