import {inject, Injectable} from "@angular/core";
import {Store} from "@ngrx/store";
import {AppState} from "../store/app.state";
import * as GroupsActions from "../store/groups/groups.actions";
import * as GroupsSelectors from "../store/groups/groups.selectors";
import {
  BaseSelectOption,
  CreateGroupRequestDto,
  GroupDto,
  UpdateGroupRequestDto
} from "@todo-frontend-workspace/shared";
import {take} from "rxjs";

@Injectable({
  providedIn: 'root'
})
export class GroupsFacade {
  private readonly store: Store<AppState> = inject(Store<AppState>);

  public readonly groups$ = this.store.select(GroupsSelectors.selectAllGroups);
  public readonly selectedGroup = this.store.selectSignal(GroupsSelectors.selectSelectedGroup);
  public readonly isLoading = this.store.selectSignal(GroupsSelectors.selectGroupsLoading);
  public readonly error$ = this.store.select(GroupsSelectors.errorSelector);

  public getGroups(): void {
    this.store.dispatch(GroupsActions.getGroups());
  }

  public searchGroups(query: string): void {
    this.store.dispatch(GroupsActions.searchGroups({ query }));
  }

  public selectGroup(id: string): void {
    this.store.dispatch(GroupsActions.selectGroup({ id }));
  }

  public createGroup(createGroupDto: CreateGroupRequestDto): void {
    this.store.select(GroupsSelectors.selectAllGroups).pipe(
      take(2) // Берем только первое изменение состояния
    ).subscribe(() => {
      console.timeEnd('Create groups'); // Фактический момент обновления стора
    });

    this.store.dispatch(GroupsActions.createGroup(createGroupDto));
  }

  public updateGroup(id: string, group: UpdateGroupRequestDto): void {
    this.store.dispatch(GroupsActions.updateGroup({ id, group }));
  }

  public deleteGroup(id: string) {
    this.store.dispatch(GroupsActions.deleteGroup({ id }));
  }

  public getOptionsGroupsList(): BaseSelectOption[] {
    const currentGroups = this.store.selectSignal(GroupsSelectors.selectAllGroups)();
    if (!currentGroups) return [];

    return currentGroups.map((group: GroupDto) => ({
      label: group.name,
      value: group.id,
    }))
  }
}
