import {inject, Injectable} from "@angular/core";
import {Store} from "@ngrx/store";
import * as GroupsSelectors from "../store/groups/groups.selectors";
import * as TaskSelectors from "../store/tasks/tasks.selectors";
import * as GroupsActions from "../store/groups/groups.actions";
import * as TaskActions from "../store/tasks/tasks.actions";
import {GroupDto, TaskDto} from "@todo-frontend-workspace/shared";
import {AppState} from "../store/app.state";

@Injectable({
  providedIn: 'root',
})
export class ModalFacade {
  private readonly store = inject(Store<AppState>);

  public readonly isManageGroupModalOpen$ = this.store.selectSignal(GroupsSelectors.selectManageFormGroupStatus);
  public readonly isManageTaskModalOpen$ = this.store.selectSignal(TaskSelectors.selectManageFormTaskStatus);
  public readonly editableGroup$ = this.store.selectSignal(GroupsSelectors.selectEditableGroup);
  public readonly editableTask$ = this.store.selectSignal(TaskSelectors.selectEditableTask);

  public openManageGroupModal(): void {
    this.store.dispatch(GroupsActions.openManageGroupModal());
  }

  public closeManageGroupModal(): void {
    this.store.dispatch(GroupsActions.closeManageGroupModal());
  }

  public setEditableGroup(group: GroupDto | null): void {
    this.store.dispatch(GroupsActions.changeEditableGroup({ group }));
  }

  public openManageTaskModal(): void {
    this.store.dispatch(TaskActions.openManageTaskModal());
  }

  public closeManageTaskModal(): void {
    this.store.dispatch(TaskActions.closeManageTaskModal());
  }

  public setEditableTask(task: TaskDto): void {
    this.store.dispatch(TaskActions.changeEditableTask({ task }));
  }

}
