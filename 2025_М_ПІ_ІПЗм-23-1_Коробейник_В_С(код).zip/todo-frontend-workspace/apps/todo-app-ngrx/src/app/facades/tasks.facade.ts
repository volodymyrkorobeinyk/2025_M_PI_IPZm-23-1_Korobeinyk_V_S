import {inject, Injectable} from "@angular/core";
import {CreateTaskRequestDto, TaskFilterType, UpdateTaskRequestDto} from "@todo-frontend-workspace/shared";
import {Store} from "@ngrx/store";
import {AppState} from "../store/app.state";
import * as TasksActions from "../store/tasks/tasks.actions";
import * as TasksSelectors from "../store/tasks/tasks.selectors";
import * as GroupsSelectors from "../store/groups/groups.selectors";

@Injectable({
  providedIn: 'root'
})
export class TasksFacade {
  private readonly store: Store<AppState> = inject(Store<AppState>);

  public readonly tasks$ = this.store.select(TasksSelectors.selectAllTasks);
  public readonly filterStatus = this.store.selectSignal(TasksSelectors.selectFilterStatus);
  public readonly isLoading = this.store.selectSignal(TasksSelectors.selectIsLoading);
  private readonly selectedGroup = this.store.selectSignal(GroupsSelectors.selectSelectedGroup);

  public getTasks(): void {
    const selectedGroup = this.selectedGroup();
    const filter = this.filterStatus();
    if (!selectedGroup) return;
    this.store.dispatch(TasksActions.getTasks({groupId: selectedGroup.id, filter}));
  }

  public createTask(createTaskRequest: CreateTaskRequestDto): void {
    this.store.dispatch(TasksActions.createTask({task: createTaskRequest}));
  }

  public updateTask(id: string, updateTaskRequest: UpdateTaskRequestDto): void {
    const oldGroupId = this.selectedGroup()!.id;
    this.store.dispatch(TasksActions.updateTask({oldGroupId, id, task: updateTaskRequest}));
  }

  public deleteTask(id: string): void {
    const groupId = this.selectedGroup()!.id;
    this.store.dispatch(TasksActions.deleteTask({groupId, id}));
  }

  public toggleCompletion(id: string): void {
    this.store.dispatch(TasksActions.toggleCompletion({id}));
  }

  public filterTasks(filterType: TaskFilterType): void {
    this.store.dispatch(TasksActions.changeFilterStatus({ filterType }));
  }
}
