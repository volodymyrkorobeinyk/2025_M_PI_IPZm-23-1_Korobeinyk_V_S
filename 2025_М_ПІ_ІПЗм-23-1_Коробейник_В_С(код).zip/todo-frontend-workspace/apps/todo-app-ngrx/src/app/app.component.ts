import { Component, inject } from '@angular/core';
import { ContentComponent } from './components/content/content.component';
import { SidebarComponent } from './components/sidebar/sidebar.component';
import {
  BaseSelectOption,
  CreateGroupRequestDto, CreateTaskRequestDto,
  ManageGroupModalComponent, ManageTaskModalComponent,
  UpdateGroupFrom, UpdateTaskForm,
} from '@todo-frontend-workspace/shared';
import { ModalFacade } from './facades/modal.facade';
import { GroupsFacade } from './facades/groups.facade';
import { TasksFacade } from './facades/tasks.facade';

@Component({
  imports: [
    ContentComponent,
    SidebarComponent,
    ManageGroupModalComponent,
    ManageTaskModalComponent,
  ],
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrl: './app.component.scss',
})
export class AppComponent {
  public title = 'todo-app-ngrx';

  private readonly modalFacade = inject(ModalFacade);
  private readonly groupsFacade = inject(GroupsFacade);
  private readonly tasksFacade = inject(TasksFacade);

  public readonly isManageGroupModalOpen = this.modalFacade.isManageGroupModalOpen$;
  public readonly isManageTaskModalOpen = this.modalFacade.isManageTaskModalOpen$;
  public readonly editableGroup = this.modalFacade.editableGroup$;
  public readonly editableTask = this.modalFacade.editableTask$;
  public readonly isLoadingGroup = this.groupsFacade.isLoading;
  public readonly isLoadingTask = this.tasksFacade.isLoading;
  public readonly selectedGroup = this.groupsFacade.selectedGroup;

  public get groupsOptions(): BaseSelectOption[] {
    return this.groupsFacade.getOptionsGroupsList();
  }

  public onCloseManageGroupModal(): void {
    this.modalFacade.closeManageGroupModal();
  }

  public onCloseManageTaskModal(): void {
    this.modalFacade.closeManageTaskModal();
  }

  public onTaskFormSubmit(data: UpdateTaskForm | CreateTaskRequestDto): void {
    if (this.editableTask()) {
      const updateTaskFrom = data as UpdateTaskForm;
      this.tasksFacade.updateTask(updateTaskFrom.id, updateTaskFrom.task);
      return;
    }

    this.tasksFacade.createTask(data as CreateTaskRequestDto);
  }

  public onGroupFormSubmit(
    data: CreateGroupRequestDto | UpdateGroupFrom
  ): void {
    if (this.editableGroup()) {
      const updateGroupFrom = data as UpdateGroupFrom;
      this.groupsFacade.updateGroup(updateGroupFrom.id, updateGroupFrom.group);
      return;
    }

    this.groupsFacade.createGroup(data as CreateGroupRequestDto);
  }
}
