import {ChangeDetectionStrategy, Component, inject, OnInit, Signal} from '@angular/core';
import { CommonModule } from '@angular/common';
import {
  BaseLogoComponent,
  FiltrationTabsComponent, GroupDto,
  GroupListComponent,
  SearchInputComponent, TaskFilterType
} from "@todo-frontend-workspace/shared";
import {Observable} from "rxjs";
import {GroupsFacade} from "../../facades/groups.facade";
import {ModalFacade} from "../../facades/modal.facade";
import {TasksFacade} from "../../facades/tasks.facade";

@Component({
  selector: 'app-sidebar',
  imports: [
    CommonModule,
    BaseLogoComponent,
    SearchInputComponent,
    FiltrationTabsComponent,
    GroupListComponent,
  ],
  templateUrl: './sidebar.component.html',
  styleUrl: './sidebar.component.scss',
  changeDetection: ChangeDetectionStrategy.OnPush,
})
export class SidebarComponent implements OnInit {
  private readonly groupsFacade = inject(GroupsFacade);
  private readonly tasksFacade = inject(TasksFacade);
  private readonly modalFacade = inject(ModalFacade);

  public readonly groups$: Observable<GroupDto[] | null> = this.groupsFacade.groups$;
  public readonly selectedGroup: Signal<GroupDto | null> = this.groupsFacade.selectedGroup;
  public readonly filterStatus: Signal<TaskFilterType> = this.tasksFacade.filterStatus;

  public readonly filterTabs= [
    {
      title: 'Favorites',
      items: [
        {
          icon: 'layout-grid',
          label: 'All',
          type: TaskFilterType.ALL,
        },
        {
          icon: 'circle-check-big',
          label: 'Completed',
          type: TaskFilterType.COMPLETED,
        },
        {
          icon: 'circle-minus',
          label: 'Uncompleted',
          type: TaskFilterType.UNCOMPLETED,
        },
      ],
    },
];

  public ngOnInit(): void {
    this.groupsFacade.getGroups();
  }

  public valueChange(value: string): void {
    this.groupsFacade.searchGroups(value);
  }

  public onTabChange(type: TaskFilterType): void {
    this.tasksFacade.filterTasks(type);
  }

  public openCreateGroupModal(): void {
    this.modalFacade.openManageGroupModal();
  }

  public openEditGroupModal(group: GroupDto): void {
    this.modalFacade.setEditableGroup(group);
    this.modalFacade.openManageGroupModal();
  }

  public deleteGroup(id: string): void {
    this.groupsFacade.deleteGroup(id);
  }

  public onGroupSelected(group: GroupDto): void {
    this.groupsFacade.selectGroup(group.id);
  }
}
