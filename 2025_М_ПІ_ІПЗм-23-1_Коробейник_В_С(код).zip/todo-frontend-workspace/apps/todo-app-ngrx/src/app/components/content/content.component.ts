import {ChangeDetectionStrategy, Component, effect, inject} from '@angular/core';
import { CommonModule } from '@angular/common';
import {BaseButtonComponent, ContentPlugComponent, TaskDto, TaskListComponent} from "@todo-frontend-workspace/shared";
import {LucideAngularModule} from "lucide-angular";
import {Observable} from "rxjs";
import {GroupsFacade} from "../../facades/groups.facade";
import {TasksFacade} from "../../facades/tasks.facade";
import {ModalFacade} from "../../facades/modal.facade";

@Component({
  selector: 'app-content',
  imports: [
    CommonModule,
    BaseButtonComponent,
    TaskListComponent,
    ContentPlugComponent,
    LucideAngularModule,
  ],
  templateUrl: './content.component.html',
  styleUrl: './content.component.scss',
  changeDetection: ChangeDetectionStrategy.OnPush,
})
export class ContentComponent {
  private readonly groupsFacade = inject(GroupsFacade);
  private readonly tasksFacade = inject(TasksFacade);
  private readonly modalFacade = inject(ModalFacade);

  public tasks$: Observable<TaskDto[] | null> = this.tasksFacade.tasks$;
  public selectedGroup = this.groupsFacade.selectedGroup;

  constructor() {
    effect(() => {
      this.loadTasksOfGroup();
    }, {});
  }

  private loadTasksOfGroup(): void {
    this.tasksFacade.getTasks();
  }

  public addTask(): void {
    this.modalFacade.openManageTaskModal();
  }

  public onTaskToggleCompletion(task: TaskDto): void {
    this.tasksFacade.toggleCompletion(task.id);
  }

  public editTask(task: TaskDto): void {
    this.modalFacade.setEditableTask(task);
    this.modalFacade.openManageTaskModal();
  }

  public deleteTask(id: string): void {
    this.tasksFacade.deleteTask(id);
  }
}
