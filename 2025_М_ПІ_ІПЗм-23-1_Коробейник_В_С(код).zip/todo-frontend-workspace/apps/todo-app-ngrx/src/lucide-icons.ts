import {
  Box,
  CircleCheckBig, CircleMinus, ClipboardList, Folder,
  Home, LayoutGrid, ListChecks, Pencil, Plus, Trash2
} from 'lucide-angular';

export const lucideIcons = {
  Home,
  CircleCheckBig,
  CircleMinus,
  Box,
  LayoutGrid,
  Plus,
  Pencil,
  Trash2,
  Folder,
  ListChecks,
  ClipboardList
};
