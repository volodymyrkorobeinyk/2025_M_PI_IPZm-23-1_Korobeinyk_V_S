import {Component, effect, inject, OnInit} from '@angular/core';
import { CommonModule } from '@angular/common';
import {BaseButtonComponent, ContentPlugComponent, TaskDto, TaskListComponent} from "@todo-frontend-workspace/shared";
import {LucideAngularModule} from "lucide-angular";
import {TasksService} from "../../state/tasks/tasks.service";
import {TasksQuery} from "../../state/tasks/tasks.query";
import {GroupsQuery} from "../../state/groups/groups.query";

@Component({
  selector: 'app-content',
  imports: [
    CommonModule,
    BaseButtonComponent,
    LucideAngularModule,
    TaskListComponent,
    ContentPlugComponent,
  ],
  templateUrl: './content.component.html',
  styleUrl: './content.component.scss',
})
export class ContentComponent implements OnInit {
  private readonly tasksService = inject(TasksService);
  private readonly tasksQuery = inject(TasksQuery);
  private readonly groupsQuery = inject(GroupsQuery);

  public tasks$ = this.tasksQuery.selectTasks$;
  public selectedGroup$ = this.groupsQuery.selectSelectedGroup$;
  public filterStatus$ = this.tasksQuery.selectFilterStatus$;

  public ngOnInit(): void {
    this.subscribeToGroupChange();
    this.subscribeToFilterChange();
  }

  private subscribeToGroupChange(): void {
    this.selectedGroup$.subscribe((group) => {
      if (group) this.loadTasksOfGroup(group.id);
    });
  }

  private subscribeToFilterChange(): void {
    this.filterStatus$.subscribe(() => {
      const group = this.groupsQuery.getValue().selectedGroup;
      if (group) this.loadTasksOfGroup(group.id);
    });
  }

  private loadTasksOfGroup(groupId: string): void {
    this.tasksService.getTasks(groupId);
  }

  public addTask(): void {
    this.tasksService.openManageTaskModal(null);
  }

  public onTaskToggleCompletion(task: TaskDto): void {
    this.tasksService.toggleTaskCompletion(task);
  }

  public editTask(task: TaskDto): void {
    this.tasksService.openManageTaskModal(task);
  }

  public deleteTask(id: string): void {
    this.tasksService.deleteTask(id);
  }
}
