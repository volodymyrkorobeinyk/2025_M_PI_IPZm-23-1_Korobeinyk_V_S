import {Component, inject, OnInit} from '@angular/core';
import { CommonModule } from '@angular/common';
import {
  BaseLogoComponent,
  FiltrationTabsComponent, GroupDto,
  GroupListComponent,
  SearchInputComponent, TaskFilterType
} from "@todo-frontend-workspace/shared";
import {Observable} from "rxjs";
import {GroupsQuery} from "../../state/groups/groups.query";
import {GroupsService} from "../../state/groups/groups.service";
import {TasksService} from "../../state/tasks/tasks.service";
import {TasksQuery} from "../../state/tasks/tasks.query";
import {toSignal} from "@angular/core/rxjs-interop";

@Component({
  selector: 'app-sidebar',
  imports: [
    CommonModule,
    BaseLogoComponent,
    FiltrationTabsComponent,
    GroupListComponent,
    SearchInputComponent,
  ],
  templateUrl: './sidebar.component.html',
  styleUrl: './sidebar.component.scss',
})
export class SidebarComponent implements OnInit {
  private readonly groupsQuery = inject(GroupsQuery)
  private readonly groupsService = inject(GroupsService)
  private readonly tasksQuery = inject(TasksQuery)
  private readonly tasksService = inject(TasksService)

  public readonly groups$: Observable<GroupDto[] | null> = this.groupsQuery.selectGroups$;
  public readonly selectedGroup$: Observable<GroupDto | null> = this.groupsQuery.selectSelectedGroup$;
  public readonly filterStatus = toSignal(this.tasksQuery.selectFilterStatus$, {initialValue: TaskFilterType.ALL});

  public readonly filterTabs= [
    {
      title: 'Favorites',
      items: [
        {
          icon: 'layout-grid',
          label: 'All',
          type: TaskFilterType.ALL,
        },
        {
          icon: 'circle-check-big',
          label: 'Completed',
          type: TaskFilterType.COMPLETED,
        },
        {
          icon: 'circle-minus',
          label: 'Uncompleted',
          type: TaskFilterType.UNCOMPLETED,
        },
      ],
    },
  ];


  public ngOnInit(): void {
    this.groupsService.getGroups();
  }

  public valueChange(value: string): void {
    this.groupsService.searchGroups(value);
  }

  public onTabChange(type: TaskFilterType): void {
    this.tasksService.changeFilterStatus(type);
  }

  public openEditGroupModal(group: GroupDto): void {
    this.groupsService.openManageGroupModal(group);
  }

  public openCreateGroupModal(): void {
    this.groupsService.openManageGroupModal(null);
  }

  public onGroupSelected(group: GroupDto): void {
    this.groupsService.selectGroup(group);
  }

  public deleteGroup(groupId: string): void {
    this.groupsService.deleteGroup(groupId);
  }
}
