import {GroupsState} from "./groups.state";
import { Query } from '@datorama/akita';
import {GroupsStore} from "./groups.store";
import {Injectable} from "@angular/core";
import {GroupDto} from "@todo-frontend-workspace/shared";

@Injectable({
  providedIn: 'root'
})
export class GroupsQuery extends Query<GroupsState> {
  // Data State
  public selectGroups$ = this.select(state => state.groups);
  public selectSelectedGroup$ = this.select(state => state.selectedGroup);

  // UI state
  public selectIsManageGroupModalOpen$ = this.select(state => state.ui.isManageGroupModalOpen);
  public selectEditableGroup$ = this.select(state => state.ui.editableGroup);
  public selectIsLoadingGroup$ = this.selectLoading();

  public getEditableGroup(): GroupDto | null {
    return this.getValue().ui.editableGroup;
  }

  constructor(private readonly groupsStore: GroupsStore) {
    super(groupsStore);
  }
}
