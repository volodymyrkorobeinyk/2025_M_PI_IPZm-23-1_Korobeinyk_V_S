import { Injectable } from '@angular/core';
import { GroupsStore } from './groups.store';
import {
  BaseSelectOption,
  CreateGroupRequestDto,
  GroupDto,
  GroupsApiService,
  UpdateGroupRequestDto,
} from '@todo-frontend-workspace/shared';
import {finalize} from 'rxjs';

@Injectable({
  providedIn: 'root',
})
export class GroupsService {
  constructor(
    private readonly groupsStore: GroupsStore,
    private readonly groupsApiService: GroupsApiService
  ) {}

  public getGroups(): void {
    this.groupsApiService.getAll().subscribe({
      next: (groups) => this.groupsStore.update({ groups }),
      error: (err) => this.groupsStore.setError(err),
    });
  }

  public searchGroups(name: string): void {
    const searchTerm = name.toLowerCase();
    this.groupsApiService.searchByName(searchTerm).subscribe({
      next: (groups) => this.groupsStore.update({ groups }),
      error: (err) => this.groupsStore.setError(err),
    });
  }

  public createGroup(group: CreateGroupRequestDto): void {
    this.groupsStore.setLoading(true);
    this.groupsApiService
      .create(group)
      .pipe(finalize(() => this.groupsStore.setLoading(false)))
      .subscribe({
        next: (createdGroup) => {
          this.groupsStore.update((state) => ({
            groups: [...state.groups!, createdGroup],
          }));
        },
        error: (err) => this.groupsStore.setError(err),
      });
  }

  public updateGroup(id: string, group: UpdateGroupRequestDto): void {
    this.groupsStore.setLoading(true);
    this.groupsApiService
      .update(id, group)
      .pipe(finalize(() => this.groupsStore.setLoading(false)))
      .subscribe({
        next: (updatedGroup) => {
          this.groupsStore.update((state) => ({
            groups: state.groups!.map((group) =>
              group.id === id ? updatedGroup : group
            ),
          }));
        },
        error: (err) => this.groupsStore.setError(err),
      });
  }

  public deleteGroup(id: string): void {
    this.groupsStore.setLoading(true);
    this.groupsApiService
      .delete(id)
      .pipe(finalize(() => this.groupsStore.setLoading(false)))
      .subscribe({
        next: () => {
          this.groupsStore.update((state) => ({
            groups: state.groups!.filter((group) => group.id !== id),
            selectedGroup: state.selectedGroup?.id === id ? null : state.selectedGroup,
          }));
        },
        error: (err) => this.groupsStore.setError(err),
      });
  }

  public selectGroup(group: GroupDto): void {
    const selectedGroup = this.groupsStore.getValue().selectedGroup;

    if (selectedGroup && selectedGroup.id === group.id) {
      this.groupsStore.update({ selectedGroup: null });
      return;
    }

    this.groupsStore.update({ selectedGroup: group });
  }

  public openManageGroupModal(group: GroupDto | null): void {
    this.groupsStore.update((groupState) => ({
      ...groupState,
      ui: {
        isManageGroupModalOpen: true,
        editableGroup: group,
      },
    }));
  }

  public closeManageGroupModal(): void {
    this.groupsStore.update((groupState) => ({
      ...groupState,
      ui: {
        isManageGroupModalOpen: false,
        editableGroup: null,
      },
    }));
  }

  public getOptionsGroupsList(): BaseSelectOption[] {
    const currentGroups = this.groupsStore.getValue().groups;
    if (!currentGroups) return [];

    return currentGroups.map((group: GroupDto) => ({
      label: group.name,
      value: group.id,
    }));
  }

  public updateGroupTaskCount(
    groupId: string,
    operation: 'increment' | 'decrement'
  ): void {
    const group = this.groupsStore.getValue().groups;
    if (!group) return;

    const updatedGroups = group.map((group) => {
      if (group.id === groupId) {
        const taskCount = operation === 'increment'
            ? Number(group.taskCount) + 1
            : Number(group.taskCount) - 1;

        return {...group, taskCount};
      }
      return group;
    });

    this.groupsStore.update({ groups: updatedGroups });
  }
}
