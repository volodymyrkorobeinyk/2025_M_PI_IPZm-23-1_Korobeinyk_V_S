import {GroupDto} from "@todo-frontend-workspace/shared";

export interface GroupsState {
  groups: GroupDto[] | null;
  selectedGroup: GroupDto | null;
  ui: {
    isManageGroupModalOpen: boolean;
    editableGroup: GroupDto | null;
  };
}

export const createInitialState = (): GroupsState => {
  return {
    groups: null,
    selectedGroup: null,
    ui: {
      isManageGroupModalOpen: false,
      editableGroup: null
    },
  }
}
