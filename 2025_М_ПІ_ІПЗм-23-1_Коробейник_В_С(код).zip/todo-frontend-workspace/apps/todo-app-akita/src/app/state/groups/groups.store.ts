import {createInitialState} from "./groups.state";
import {GroupsState} from "./groups.state";
import {Store} from "@datorama/akita";
import {StoreConfig} from "@datorama/akita";
import {Injectable} from "@angular/core";

@Injectable({
  providedIn: 'root'
})
@StoreConfig({ name: 'groups' })
export class GroupsStore extends Store<GroupsState> {
  constructor() {
    super(createInitialState());
  }
}
