import { Injectable } from '@angular/core';
import { Query } from '@datorama/akita';
import { TaskDto } from '@todo-frontend-workspace/shared';
import { TasksState } from './tasks.state';
import { TasksStore } from './tasks.store';

@Injectable({
  providedIn: 'root',
})
export class TasksQuery extends Query<TasksState> {
  // Data State
  public selectTasks$ = this.select((state) => state.tasks);

  // UI state
  public selectIsManageTaskModalOpen$ = this.select((state) => state.ui.isManageTaskModalOpen);
  public selectEditableTask$ = this.select((state) => state.ui.editableTask);
  public selectFilterStatus$ = this.select((state) => state.ui.filterStatus);
  public selectIsLoadingTask$ = this.selectLoading();

  public getEditableTask(): TaskDto | null {
    return this.getValue().ui.editableTask;
  }

  constructor(private readonly tasksStore: TasksStore) {
    super(tasksStore);
  }
}
