import {Injectable} from "@angular/core";
import {Store, StoreConfig} from "@datorama/akita";
import {createInitialState, TasksState} from "./tasks.state";

@Injectable({
  providedIn: 'root'
})
@StoreConfig({ name: 'tasks' })
export class TasksStore extends Store<TasksState> {
  constructor() {
    super(createInitialState());
  }
}
