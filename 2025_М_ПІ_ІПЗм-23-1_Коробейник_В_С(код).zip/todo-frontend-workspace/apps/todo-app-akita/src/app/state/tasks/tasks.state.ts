import {TaskDto, TaskFilterType} from "@todo-frontend-workspace/shared";

export interface TasksState {
  tasks: TaskDto[] | null;
  ui: {
    filterStatus: TaskFilterType
    isManageTaskModalOpen: boolean;
    editableTask: TaskDto | null;
  };
}

export const createInitialState = (): TasksState => {
  return {
    tasks: null,
    ui: {
      filterStatus: TaskFilterType.ALL,
      isManageTaskModalOpen: false,
      editableTask: null
    },
  }
}
