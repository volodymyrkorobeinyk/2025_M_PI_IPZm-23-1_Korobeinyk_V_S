import { Injectable } from '@angular/core';
import {
  CreateTaskRequestDto,
  TaskDto,
  TaskFilterType,
  TasksApiService,
  UpdateTaskRequestDto,
} from '@todo-frontend-workspace/shared';
import { TasksStore } from './tasks.store';
import { GroupsService } from '../groups/groups.service';
import {finalize} from "rxjs";

@Injectable({
  providedIn: 'root',
})
export class TasksService {
  constructor(
    private readonly tasksStore: TasksStore,
    private readonly tasksApiService: TasksApiService,
    private readonly groupsService: GroupsService
  ) {}

  public getTasks(groupId: string): void {
    const filter = this.tasksStore.getValue().ui.filterStatus;
    this.tasksApiService
      .getAllByGroupId(groupId, filter)
      .subscribe((tasks) =>
        this.tasksStore.update((state) => ({ ...state, tasks }))
      );
  }

  public createTask(task: CreateTaskRequestDto): void {
    this.tasksStore.setLoading(true);
    this.tasksApiService.create(task)
      .pipe(finalize(() => this.tasksStore.setLoading(false)))
      .subscribe({
      next: (task) => {
        this.tasksStore.update((state) => ({
          ...state,
          tasks: [...state.tasks!, task],
        }));
        console.log(this.tasksStore.getValue().tasks)
        this.groupsService.updateGroupTaskCount(task.groupId, 'increment');
      },
      error: (error) => this.tasksStore.setError(error),
    });
  }

  public updateTask(taskId: string, task: UpdateTaskRequestDto): void {
    this.tasksStore.setLoading(true);
    this.tasksApiService.update(taskId, task)
      .pipe(finalize(() => this.tasksStore.setLoading(false)))
      .subscribe({
      next: (updatedTask) => {
        this.tasksStore.update((state) => {
          const oldTask = state.tasks!.find(t => t.id === taskId)!;
          if (oldTask.groupId !== updatedTask.groupId) {
            this.groupsService.updateGroupTaskCount(oldTask.groupId, 'decrement');
            this.groupsService.updateGroupTaskCount(updatedTask.groupId, 'increment');
            return {
              ...state,
              tasks: state.tasks!.filter((t) => t.id !== taskId),
            }
          }
          return {
            ...state,
            tasks: state.tasks!.map((t) => (t.id === taskId ? updatedTask : t)),
          };
        });

      },
      error: (error) => this.tasksStore.setError(error)
    });
  }

  public deleteTask(taskId: string): void {
    this.tasksStore.setLoading(true);
    this.tasksApiService.delete(taskId)
      .pipe(finalize(() => this.tasksStore.setLoading(false)))
      .subscribe({
      next: () => {
        let groupId = '';
        this.tasksStore.update((state) => ({
          ...state,
          tasks: state.tasks!.filter((task) => {
            if (task.id !== taskId) return task;
            groupId = task.groupId;
            return null;
          }),
        }));
        this.groupsService.updateGroupTaskCount(groupId, 'decrement');
      },
      error: (error) => this.tasksStore.setError(error),
    });
  }

  public toggleTaskCompletion(task: TaskDto): void {
    this.tasksApiService.toggleCompletion(task.id)
      .subscribe({
        next: (updatedTask) => {
          this.tasksStore.update((state) => ({
            ...state,
            tasks: state.tasks!.map((t) => (t.id === task.id ? updatedTask : t)),
          }));
        },
        error: (error) => this.tasksStore.setError(error),
      })
  }

  public openManageTaskModal(task: TaskDto | null): void {
    this.tasksStore.update((state) => ({
      ...state,
      ui: {
        ...state.ui,
        isManageTaskModalOpen: true,
        editableTask: task,
      },
    }));
  }

  public closeManageTaskModal(): void {
    this.tasksStore.update((state) => ({
      ...state,
      ui: {
        ...state.ui,
        isManageTaskModalOpen: false,
        editableTask: null,
      },
    }));
  }

  public changeFilterStatus(filterStatus: TaskFilterType): void {
    this.tasksStore.update((state) => ({
      ...state,
      ui: { ...state.ui, filterStatus },
    }));
  }
}
