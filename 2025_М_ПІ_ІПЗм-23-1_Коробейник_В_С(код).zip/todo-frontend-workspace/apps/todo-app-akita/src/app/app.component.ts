import {Component, inject} from '@angular/core';
import {
  BaseSelectOption,
  CreateGroupRequestDto, CreateTaskRequestDto,
  ManageGroupModalComponent,
  ManageTaskModalComponent, UpdateGroupFrom, UpdateTaskForm
} from "@todo-frontend-workspace/shared";
import {SidebarComponent} from "./components/sidebar/sidebar.component";
import {ContentComponent} from "./components/content/content.component";
import {GroupsService} from "./state/groups/groups.service";
import {GroupsQuery} from "./state/groups/groups.query";
import {AsyncPipe} from "@angular/common";
import {TasksQuery} from "./state/tasks/tasks.query";
import {TasksService} from "./state/tasks/tasks.service";
import {toSignal} from "@angular/core/rxjs-interop";

@Component({
  imports: [
    ContentComponent,
    ManageGroupModalComponent,
    ManageTaskModalComponent,
    SidebarComponent,
    AsyncPipe,
  ],
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrl: './app.component.scss',
})
export class AppComponent {
  public title = 'todo-app-akita';

  private readonly groupsService = inject(GroupsService);
  private readonly groupsQuery = inject(GroupsQuery);
  private readonly tasksQuery = inject(TasksQuery);
  private readonly tasksService = inject(TasksService);

  public readonly isManageGroupModalOpen = toSignal(this.groupsQuery.selectIsManageGroupModalOpen$, {initialValue: false});
  public readonly isLoadingGroup = toSignal(this.groupsQuery.selectIsLoadingGroup$, {initialValue: false});
  public readonly isManageTaskModalOpen = toSignal(this.tasksQuery.selectIsManageTaskModalOpen$, {initialValue: false});
  public readonly isLoadingTask = toSignal(this.tasksQuery.selectIsLoadingTask$, {initialValue: false});
  public readonly editableGroup$ = this.groupsQuery.selectEditableGroup$;
  public readonly editableTask$ = this.tasksQuery.selectEditableTask$;
  public readonly selectedGroup$ = this.groupsQuery.selectSelectedGroup$;

  public get groupsOptions(): BaseSelectOption[] {
    return this.groupsService.getOptionsGroupsList();
  }

  public onGroupFormSubmit(
    data: CreateGroupRequestDto | UpdateGroupFrom
  ): void {
    const editableGroup = this.groupsQuery.getEditableGroup();
    if (editableGroup) {
      const updateGroupFrom = data as UpdateGroupFrom;
      this.groupsService.updateGroup(updateGroupFrom.id, updateGroupFrom.group);
      return;
    }

    this.groupsService.createGroup(data as CreateGroupRequestDto);
  }

  public onTaskFormSubmit(data: UpdateTaskForm | CreateTaskRequestDto): void {
    const editableTask = this.tasksQuery.getEditableTask();
    if (editableTask) {
      const updateTaskFrom = data as UpdateTaskForm;
      this.tasksService.updateTask(updateTaskFrom.id, updateTaskFrom.task);
      return;
    }

    this.tasksService.createTask(data as CreateTaskRequestDto);
  }

  public onCloseManageGroupModal(): void {
    this.groupsService.closeManageGroupModal();
  }

  public onCloseManageTaskModal(): void {
    this.tasksService.closeManageTaskModal();
  }
}
