import {ArrayState, NgxState} from "ngx-base-state";
import {Injectable} from "@angular/core";
import {TaskDto} from "@todo-frontend-workspace/shared";

@NgxState()
@Injectable({
  providedIn: 'root'
})
export class TasksState extends ArrayState<TaskDto> {
  protected override getItemId(task: TaskDto): string {
    return task.id;
  }

  public findById(taskId: string): TaskDto | null {
    return this.data?.find(task => task.id === taskId) ?? null;
  }
}
