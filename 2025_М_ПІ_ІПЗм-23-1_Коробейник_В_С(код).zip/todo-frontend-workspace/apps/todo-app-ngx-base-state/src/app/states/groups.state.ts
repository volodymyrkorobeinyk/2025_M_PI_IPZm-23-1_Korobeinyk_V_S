import {ArrayState, NgxState} from "ngx-base-state";
import {Injectable} from "@angular/core";
import {GroupDto} from "@todo-frontend-workspace/shared";

@NgxState()
@Injectable({
  providedIn: 'root'
})
export class GroupsState extends ArrayState<GroupDto> {
  protected override getItemId(group: GroupDto): string {
    return group.id;
  }

  public findById(id: string): GroupDto | null {
    return this.data?.find(group => group.id === id) || null;
  }
}
