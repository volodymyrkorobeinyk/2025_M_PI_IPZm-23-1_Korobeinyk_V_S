import { Component, inject, signal } from '@angular/core';
import { RouterModule } from '@angular/router';
import { LucideAngularModule } from 'lucide-angular';
import { SidebarComponent } from './components/sidebar/sidebar.component';
import { ContentComponent } from './components/content/content.component';
import {
  BaseSelectOption,
  CreateGroupRequestDto,
  CreateTaskRequestDto,
  ManageGroupModalComponent,
  ManageTaskModalComponent,
  UpdateGroupFrom,
  UpdateGroupRequestDto,
  UpdateTaskForm,
} from '@todo-frontend-workspace/shared';
import { ManageGroupModalService } from './services/manage-group-modal.service';
import { GroupsManageService } from './services/groups-manage.service';
import { finalize } from 'rxjs';
import { ManageTaskModalService } from './services/manage-task-modal.service';
import { TasksManageService } from './services/tasks-manage.service';
import { SelectedGroupService } from './services/selected-group.service';

@Component({
  imports: [
    RouterModule,
    LucideAngularModule,
    SidebarComponent,
    ContentComponent,
    ManageGroupModalComponent,
    ManageTaskModalComponent,
  ],
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrl: './app.component.scss',
})
export class AppComponent {
  public title = 'To Do App';
  public inProgress = signal<boolean>(false);

  public get groupsOptions(): BaseSelectOption[] {
    return this.groupsManageService.getOptionsGroupsList();
  }

  private readonly manageGroupModalService = inject(ManageGroupModalService);
  private readonly manageTaskModalService = inject(ManageTaskModalService);
  private readonly groupsManageService = inject(GroupsManageService);
  private readonly tasksManageService = inject(TasksManageService);
  private readonly selectedGroupService = inject(SelectedGroupService);

  public selectedGroup = this.selectedGroupService.selectedGroupSignal;
  public editableGroup = this.manageGroupModalService.editableGroup;
  public editableTask = this.manageTaskModalService.editableTask;
  public isOpenManageGroupModal = this.manageGroupModalService.modalState;
  public isOpenManageTaskModal = this.manageTaskModalService.modalState;

  public onCloseManageGroupModal(): void {
    this.manageGroupModalService.setIsOpen(false);
  }

  public onCloseManageTaskModal(): void {
    this.manageTaskModalService.setIsOpen(false);
  }

  public onTaskFormSubmit(data: UpdateTaskForm | CreateTaskRequestDto): void {
    this.inProgress.set(true);
    if (this.editableTask()) {
      const updateTaskFrom = <UpdateTaskForm>data;
      this.tasksManageService
        .update(updateTaskFrom.id, updateTaskFrom.task)
        .pipe(finalize(() => this.inProgress.set(false)))
        .subscribe();
      return;
    }

    this.tasksManageService
      .create(<CreateTaskRequestDto>data)
      .pipe(finalize(() => this.inProgress.set(false)))
      .subscribe();
  }

  public onGroupFormSubmit(
    data: UpdateGroupFrom | CreateGroupRequestDto
  ): void {
    this.inProgress.set(true);
    if (this.editableGroup()) {
      const updateGroupFrom = <UpdateGroupFrom>data;
      this.groupsManageService
        .update(
          updateGroupFrom.id,
          <UpdateGroupRequestDto>updateGroupFrom.group
        )
        .pipe(finalize(() => this.inProgress.set(false)))
        .subscribe();
      return;
    }

    this.groupsManageService
      .create(<CreateGroupRequestDto>data)
      .pipe(finalize(() => this.inProgress.set(false)))
      .subscribe();
  }
}
