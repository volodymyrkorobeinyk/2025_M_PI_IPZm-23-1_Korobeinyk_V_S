import {
  ChangeDetectionStrategy,
  Component,
  effect,
  inject,
  Signal,
} from '@angular/core';
import { CommonModule } from '@angular/common';
import { SelectedGroupService } from '../../services/selected-group.service';
import {
  BaseButtonComponent,
  ContentPlugComponent,
  GroupDto,
  TaskDto,
  TaskListComponent,
} from '@todo-frontend-workspace/shared';
import { LucideAngularModule } from 'lucide-angular';
import { Observable } from 'rxjs';
import { TasksManageService } from '../../services/tasks-manage.service';
import { ManageTaskModalService } from '../../services/manage-task-modal.service';
import { FiltrationStatusService } from '../../services/filtration-status.service';

@Component({
  selector: 'app-content',
  imports: [
    CommonModule,
    BaseButtonComponent,
    LucideAngularModule,
    TaskListComponent,
    ContentPlugComponent,
  ],
  templateUrl: './content.component.html',
  styleUrl: './content.component.scss',
  changeDetection: ChangeDetectionStrategy.OnPush,
})
export class ContentComponent {
  public selectedGroup: Signal<GroupDto | null>;
  public tasks$: Observable<TaskDto[] | null>;

  private readonly selectedGroupService = inject(SelectedGroupService);
  private readonly taskManageService = inject(TasksManageService);
  private readonly manageTaskModalService = inject(ManageTaskModalService);
  private readonly filterStatusService = inject(FiltrationStatusService);

  public constructor() {
    this.initTasksObservable();
    this.initSelectedGroupSignal();

    effect(() => {
      this.loadTasksOfGroup();
    }, {});
  }

  public addTask(): void {
    if (this.manageTaskModalService.editableTask()) {
      this.manageTaskModalService.setEditableTask(null);
    }
    this.manageTaskModalService.setIsOpen(true);
  }

  public editTask(task: TaskDto): void {
    this.manageTaskModalService.setEditableTask(task);
    this.manageTaskModalService.setIsOpen(true);
  }

  public deleteTask(id: string): void {
    this.taskManageService.delete(id).subscribe();
  }

  public onTaskToggleCompletion(task: TaskDto): void {
    this.taskManageService.toggleCompletion(task.id).subscribe();
  }

  private initSelectedGroupSignal(): void {
    this.selectedGroup = this.selectedGroupService.selectedGroupSignal;
  }

  private initTasksObservable(): void {
    this.tasks$ = this.taskManageService.tasks$;
  }

  private loadTasksOfGroup(): void {
    const group = this.selectedGroup();
    if (group) {
      const filter = this.filterStatusService.filterStatus();
      this.taskManageService.getAllByGroup(group.id, filter).subscribe();
    }
  }
}
