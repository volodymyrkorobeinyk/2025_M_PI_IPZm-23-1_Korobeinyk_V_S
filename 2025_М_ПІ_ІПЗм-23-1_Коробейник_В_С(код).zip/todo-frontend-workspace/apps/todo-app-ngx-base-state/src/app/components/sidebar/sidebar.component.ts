import {
  ChangeDetectionStrategy,
  Component,
  inject,
  OnInit,
} from '@angular/core';
import { CommonModule } from '@angular/common';
import {
  BaseLogoComponent,
  FiltrationTabsComponent,
  GroupDto,
  GroupListComponent,
  SearchInputComponent,
  TaskFilterType,
} from '@todo-frontend-workspace/shared';
import { GroupsManageService } from '../../services/groups-manage.service';
import { Observable } from 'rxjs';
import { SelectedGroupService } from '../../services/selected-group.service';
import { ManageGroupModalService } from '../../services/manage-group-modal.service';
import { FiltrationStatusService } from '../../services/filtration-status.service';

@Component({
  selector: 'app-sidebar',
  imports: [
    CommonModule,
    BaseLogoComponent,
    SearchInputComponent,
    FiltrationTabsComponent,
    GroupListComponent,
  ],
  templateUrl: './sidebar.component.html',
  styleUrl: './sidebar.component.scss',
  changeDetection: ChangeDetectionStrategy.OnPush,
})
export class SidebarComponent implements OnInit {
  private readonly filterStatusService = inject(FiltrationStatusService);

  public groups$: Observable<GroupDto[] | null>;

  public filterStatus = this.filterStatusService.filterStatus;

  public get selectedGroup(): GroupDto | null {
    return this.selectedGroupService.getSelectedGroup();
  }

  public filterTabs = [
    {
      title: 'Favorites',
      items: [
        {
          icon: 'layout-grid',
          label: 'All',
          type: TaskFilterType.ALL,
        },
        {
          icon: 'circle-check-big',
          label: 'Completed',
          type: TaskFilterType.COMPLETED,
        },
        {
          icon: 'circle-minus',
          label: 'Uncompleted',
          type: TaskFilterType.UNCOMPLETED,
        },
      ],
    },
  ];

  private readonly groupsManageService = inject(GroupsManageService);
  private readonly selectedGroupService = inject(SelectedGroupService);
  private readonly manageGroupModalService = inject(ManageGroupModalService);

  public ngOnInit(): void {
    this.initGroupsObservable();
    this.loadGroupsData();
  }

  private initGroupsObservable(): void {
    this.groups$ = this.groupsManageService.groups$;
  }

  private loadGroupsData(): void {
    this.groupsManageService.getAll().subscribe();
  }

  public onGroupSelected(group: GroupDto): void {
    const selectedGroup = this.selectedGroup?.id === group.id ? null : group;
    this.selectedGroupService.setSelectedGroup(selectedGroup);
  }

  public openCreateGroupModal(): void {
    if (this.manageGroupModalService.editableGroup()) {
      this.manageGroupModalService.setEditableGroup(null);
    }
    this.manageGroupModalService.setIsOpen(true);
  }

  public openEditGroupModal(group: GroupDto): void {
    this.manageGroupModalService.setEditableGroup(group);
    this.manageGroupModalService.setIsOpen(true);
  }

  public deleteGroup(id: string): void {
    this.groupsManageService.delete(id).subscribe();
  }

  public onTabChange(type: TaskFilterType): void {
    this.filterStatusService.setFilterStatus(type);
  }

  public valueChange(value: string): void {
    this.groupsManageService.searchGroupsByName(value);
  }
}
