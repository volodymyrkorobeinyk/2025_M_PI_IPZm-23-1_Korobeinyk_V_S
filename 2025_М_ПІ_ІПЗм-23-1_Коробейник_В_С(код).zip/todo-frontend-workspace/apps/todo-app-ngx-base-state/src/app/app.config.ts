import {ApplicationConfig, importProvidersFrom, provideZoneChangeDetection} from '@angular/core';
import {LucideAngularModule} from "lucide-angular";
import {lucideIcons} from "../lucide-icons";
import {provideHttpClient} from "@angular/common/http";

export const appConfig: ApplicationConfig = {
  providers: [
    provideZoneChangeDetection({ eventCoalescing: true }),
    importProvidersFrom(LucideAngularModule.pick(lucideIcons)),
    provideHttpClient()
  ],
};
