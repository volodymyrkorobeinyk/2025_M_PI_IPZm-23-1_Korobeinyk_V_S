import { Injectable, signal, Signal } from '@angular/core';
import { GroupDto } from '@todo-frontend-workspace/shared';

@Injectable({
  providedIn: 'root',
})
export class SelectedGroupService {
  private selectedGroup = signal<GroupDto | null>(null);

  public setSelectedGroup(group: GroupDto | null): void {
    this.selectedGroup.set(group);
  }

  public get selectedGroupSignal(): Signal<GroupDto | null> {
    return this.selectedGroup;
  }

  public getSelectedGroup(): GroupDto | null {
    return this.selectedGroup();
  }
}
