import {Injectable, Signal, signal} from "@angular/core";
import {TaskFilterType} from "@todo-frontend-workspace/shared";

@Injectable({
  providedIn: 'root'
})
export class FiltrationStatusService {
  public readonly filterStatusSignal = signal<TaskFilterType>(TaskFilterType.ALL);

  public setFilterStatus(status: TaskFilterType): void {
    this.filterStatusSignal.set(status);
  }

  public get filterStatus(): Signal<TaskFilterType> {
    return this.filterStatusSignal;
  }
}
