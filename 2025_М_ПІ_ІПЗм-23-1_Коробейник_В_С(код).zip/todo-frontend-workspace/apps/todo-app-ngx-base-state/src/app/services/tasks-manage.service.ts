import { Injectable } from '@angular/core';
import { Observable, tap } from 'rxjs';
import {
  CreateTaskRequestDto,
  TaskDto, TaskFilterType,
  TasksApiService,
  UpdateTaskRequestDto,
} from '@todo-frontend-workspace/shared';
import { TasksState } from '../states/tasks.state';
import { GroupsManageService } from './groups-manage.service';

@Injectable({
  providedIn: 'root',
})
export class TasksManageService {
  public readonly tasks$: Observable<TaskDto[] | null> = this.tasksState.data$;

  constructor(
    private readonly tasksState: TasksState,
    private readonly tasksApiService: TasksApiService,
    private readonly groupsManageService: GroupsManageService
  ) {}

  public getAllByGroup(groupId: string, filter: TaskFilterType): Observable<TaskDto[]> {
    return this.tasksApiService.getAllByGroupId(groupId, filter).pipe(
      tap((tasks: TaskDto[]) => this.tasksState.set(tasks))
    );
  }

  public toggleCompletion(id: string): Observable<TaskDto> {
    return this.tasksApiService.toggleCompletion(id).pipe(
      tap((updatedTask: TaskDto) => this.tasksState.updateItem(updatedTask))
    );
  }

  public create(task: CreateTaskRequestDto): Observable<TaskDto> {
    return this.tasksApiService.create(task).pipe(
      tap((newTask: TaskDto) => {
        this.tasksState.pushItem(newTask);
        this.groupsManageService.updateGroupTaskCount(newTask.groupId, 'increment');
      })
    );
  }

  public update(id: string, task: UpdateTaskRequestDto): Observable<TaskDto> {
    const oldTask = { ...this.tasksState.findById(id)! };

    return this.tasksApiService.update(id, task).pipe(
      tap((updatedTask: TaskDto) => {
        if (oldTask.groupId !== updatedTask.groupId) {
          this.tasksState.removeItemById(id);
          this.groupsManageService.updateGroupTaskCount(oldTask.groupId, 'decrement');
          this.groupsManageService.updateGroupTaskCount(updatedTask.groupId, 'increment');
        } else {
          this.tasksState.updateItem(updatedTask);
        }
      })
    );
  }

  public delete(id: string): Observable<any> {
    const task = this.tasksState.findById(id);

    if (!task) {
      throw new Error(`Task with id ${id} not found`);
    }

    return this.tasksApiService.delete(id).pipe(
      tap(() => {
        this.tasksState.removeItemById(id);
        this.groupsManageService.updateGroupTaskCount(task.groupId, 'decrement');
      })
    );
  }
}
