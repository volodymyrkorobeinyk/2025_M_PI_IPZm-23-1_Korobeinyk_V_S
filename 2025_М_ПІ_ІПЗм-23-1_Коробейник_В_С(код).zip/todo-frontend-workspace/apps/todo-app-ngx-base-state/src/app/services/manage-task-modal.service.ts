import {Injectable, Signal, signal} from '@angular/core';
import { TaskDto } from '@todo-frontend-workspace/shared';

@Injectable({
  providedIn: 'root',
})
export class ManageTaskModalService {
  private readonly isOpen = signal<boolean>(false);
  private readonly editableTaskSignal = signal<TaskDto | null>(null);

  public setIsOpen(value: boolean): void {
    return this.isOpen.set(value);
  }

  public get modalState(): Signal<boolean> {
    return this.isOpen;
  }

  public setEditableTask(group: TaskDto | null): void {
    this.editableTaskSignal.set(group);
  }

  public get editableTask(): Signal<TaskDto | null> {
    return this.editableTaskSignal;
  }
}
