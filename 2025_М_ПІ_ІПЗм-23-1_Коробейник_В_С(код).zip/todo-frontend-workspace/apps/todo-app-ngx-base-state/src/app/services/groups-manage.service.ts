import { Injectable } from '@angular/core';
import { GroupsState } from '../states/groups.state';
import {
  CreateGroupRequestDto,
  GroupDto,
  GroupsApiService,
  UpdateGroupRequestDto
} from '@todo-frontend-workspace/shared';
import { Observable, tap } from 'rxjs';
import {BaseSelectOption} from "@todo-frontend-workspace/shared";
import {SelectedGroupService} from "./selected-group.service";

@Injectable({
  providedIn: 'root',
})
export class GroupsManageService {
  public readonly groups$: Observable<GroupDto[] | null> = this.groupState.data$;

  constructor(
    private readonly groupState: GroupsState,
    private readonly groupsApiService: GroupsApiService,
    private readonly selectedGroupService: SelectedGroupService
  ) {}

  public getAll(): Observable<GroupDto[]> {
    return this.groupsApiService.getAll()
      .pipe(tap((groups: GroupDto[]) => this.groupState.set(groups))
    );
  }

  public create(group: CreateGroupRequestDto): Observable<GroupDto> {
    return this.groupsApiService.create(group)
      .pipe(tap((newGroup: GroupDto) => {
        this.groupState.pushItem(newGroup);
      })
    );
  }

  public update(id: string, group: UpdateGroupRequestDto): Observable<GroupDto> {
    return this.groupsApiService.update(id, group)
      .pipe(tap((updatedGroup: GroupDto) => {
        if (this.selectedGroupService.selectedGroupSignal()?.id === updatedGroup.id) {
          this.selectedGroupService.setSelectedGroup(updatedGroup);
        }
        this.groupState.updateItem(updatedGroup)
      }));
  }

  public delete(id: string): Observable<any> {
    return this.groupsApiService.delete(id)
      .pipe(tap(() => this.groupState.removeItemById(id)));
  }

  public getOptionsGroupsList(): BaseSelectOption[] {
    const currentGroups = this.groupState.data;
    if (!currentGroups) return [];

    return currentGroups.map((group: GroupDto) => ({
      label: group.name,
      value: group.id,
    }));
  }

  public searchGroupsByName(name: string): void {
    const searchTerm = name.toLowerCase();
    this.groupsApiService.searchByName(searchTerm)
      .pipe(tap((groups: GroupDto[]) => this.groupState.set(groups)))
      .subscribe();
  }

  public updateGroupTaskCount(groupId: string, operation: 'increment' | 'decrement' ): void {
    const group = this.groupState.findById(groupId);

    if (!group) return;

    const taskCount = operation === 'increment' ? Number(group.taskCount) + 1 : Number(group.taskCount) - 1;

      this.groupState.updateItem({
      ...group,
      taskCount: taskCount,
    });
  }
}
