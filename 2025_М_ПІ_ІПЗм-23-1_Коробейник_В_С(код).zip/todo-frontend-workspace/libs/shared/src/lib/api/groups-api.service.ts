import { Injectable } from '@angular/core';
import {HttpClient, HttpHeaders} from "@angular/common/http";
import {Observable} from "rxjs";
import {GroupDto} from "../models";
import {CreateGroupRequestDto} from "../models";
import {UpdateGroupRequestDto} from "../models";
import {environment} from "../environment";

@Injectable({
  providedIn: 'root'
})
export class GroupsApiService {

  private headers = new HttpHeaders({
    'Content-Type': 'application/json'
  });

  constructor(
    private readonly http: HttpClient
  ) { }

  public getAll(): Observable<GroupDto[]> {
    const options = {
      headers: this.headers,
    };

    return this.http.get<GroupDto[]>(environment.url + "/groups", options);
  }

  public searchByName(name: string): Observable<GroupDto[]> {
    const options = {
      headers: this.headers,
    };

    return this.http.get<GroupDto[]>(environment.url + `/groups/search?name=${name}`, options);
  }

  public create(group: CreateGroupRequestDto): Observable<GroupDto> {
    const options = {
      headers: this.headers,
    };

    return this.http.post<GroupDto>(environment.url + "/groups", group, options);
  }

  public update(id: string, group: UpdateGroupRequestDto): Observable<GroupDto> {
    const options = {
      headers: this.headers,
    };

    return this.http.patch<GroupDto>(environment.url + `/groups/${id}`, group, options);
  }

  public delete(id: string): Observable<GroupDto> {
    const options = {
      headers: this.headers,
    };

    return this.http.delete<GroupDto>(environment.url + `/groups/${id}`, options);
  }
}
