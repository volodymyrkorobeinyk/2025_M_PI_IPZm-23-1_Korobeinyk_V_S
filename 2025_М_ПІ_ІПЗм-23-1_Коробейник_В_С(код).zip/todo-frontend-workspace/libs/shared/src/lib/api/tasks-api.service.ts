import { Injectable } from '@angular/core';
import {HttpClient, HttpHeaders} from "@angular/common/http";
import {Observable} from "rxjs";
import {CreateTaskRequestDto, UpdateTaskRequestDto, TaskDto} from "../models";
import {environment} from "../environment";
import {TaskFilterType} from "../types";

@Injectable({
  providedIn: 'root'
})
export class TasksApiService {

  private headers = new HttpHeaders({
    'Content-Type': 'application/json'
  });

  constructor(
    private readonly http: HttpClient
  ) { }

  public getAllByGroupId(groupId: string, filter: TaskFilterType): Observable<TaskDto[]> {
    const options = {
      headers: this.headers,
      params: {
        filter: filter
      }
    };

    return this.http.get<TaskDto[]>(environment.url + `/tasks/${groupId}`, options);
  }

  public toggleCompletion(id: string): Observable<TaskDto> {
    const options = {
      headers: this.headers,
    };

    return this.http.patch<TaskDto>(environment.url + `/tasks/toggleCompletion/${id}`, {}, options);
  }

  public create(task: CreateTaskRequestDto): Observable<TaskDto> {
    const options = {
      headers: this.headers,
    };

    return this.http.post<TaskDto>(environment.url + "/tasks", task, options);
  }

  public update(id: string, task: UpdateTaskRequestDto): Observable<TaskDto> {
    const options = {
      headers: this.headers,
    };

    return this.http.patch<TaskDto>(environment.url + `/tasks/${id}`, task, options);
  }

  public delete(id: string): Observable<TaskDto> {
    const options = {
      headers: this.headers,
    };

    return this.http.delete<TaskDto>(environment.url + `/tasks/${id}`, options);
  }
}
