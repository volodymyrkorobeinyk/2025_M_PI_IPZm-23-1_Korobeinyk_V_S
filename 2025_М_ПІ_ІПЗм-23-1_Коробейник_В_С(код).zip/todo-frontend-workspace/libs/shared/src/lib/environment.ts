export const environment = {
  production: false,
  url: 'http://localhost:5002',
  schema: 'http',
  domain: 'localhost',
};
