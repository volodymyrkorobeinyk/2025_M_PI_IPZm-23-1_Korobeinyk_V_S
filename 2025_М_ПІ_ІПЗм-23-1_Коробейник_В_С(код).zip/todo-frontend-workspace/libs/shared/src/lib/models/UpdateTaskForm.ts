import { UpdateTaskRequestDto } from './api/UpdateTaskRequestDto';

export interface UpdateTaskForm {
  id: string;
  task: UpdateTaskRequestDto;
}
