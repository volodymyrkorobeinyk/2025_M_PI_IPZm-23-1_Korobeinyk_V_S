export interface CreateGroupRequestDto {
  readonly name: string;
}
