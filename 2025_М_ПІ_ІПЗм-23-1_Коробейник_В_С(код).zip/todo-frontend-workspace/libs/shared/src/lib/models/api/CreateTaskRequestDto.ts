export interface CreateTaskRequestDto {
  readonly groupId: string;
  readonly title: string;
  readonly description?: string;
}
