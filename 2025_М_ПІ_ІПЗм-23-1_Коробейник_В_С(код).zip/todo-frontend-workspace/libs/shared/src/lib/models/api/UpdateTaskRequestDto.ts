export interface UpdateTaskRequestDto {
  readonly groupId: string;
  readonly title: string;
  readonly description?: string;
}
