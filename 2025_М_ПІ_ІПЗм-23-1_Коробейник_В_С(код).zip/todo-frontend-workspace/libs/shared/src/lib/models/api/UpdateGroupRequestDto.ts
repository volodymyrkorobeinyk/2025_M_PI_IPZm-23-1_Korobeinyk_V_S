export interface UpdateGroupRequestDto {
  readonly name: string;
}
