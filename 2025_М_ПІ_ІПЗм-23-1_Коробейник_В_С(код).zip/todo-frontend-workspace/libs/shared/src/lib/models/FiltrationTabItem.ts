import {TaskFilterType} from "../types/TaskFilterType";

export interface FiltrationTabItem {
  icon: string;
  label: string;
  type: TaskFilterType;
}
