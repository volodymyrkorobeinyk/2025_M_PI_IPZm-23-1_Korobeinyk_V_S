import {UpdateGroupRequestDto} from "./api/UpdateGroupRequestDto";

export interface UpdateGroupFrom {
  id: string;
  group: UpdateGroupRequestDto
}
