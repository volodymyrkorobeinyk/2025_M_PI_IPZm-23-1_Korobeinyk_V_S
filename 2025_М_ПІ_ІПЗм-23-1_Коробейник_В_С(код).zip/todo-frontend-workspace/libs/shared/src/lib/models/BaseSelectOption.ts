export interface BaseSelectOption {
  label: string;
  value: any;
}
