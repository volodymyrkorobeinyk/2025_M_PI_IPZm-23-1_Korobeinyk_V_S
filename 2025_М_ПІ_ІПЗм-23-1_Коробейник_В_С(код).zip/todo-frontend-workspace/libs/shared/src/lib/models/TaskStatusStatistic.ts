export interface TaskStatusStatistic {
  allCount: number;
  completedCount: number;
  uncompletedCount: number;
}
