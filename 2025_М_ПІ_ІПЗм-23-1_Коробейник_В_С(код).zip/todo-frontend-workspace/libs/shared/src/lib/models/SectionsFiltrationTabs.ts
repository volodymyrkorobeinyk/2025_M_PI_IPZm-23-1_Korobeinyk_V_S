import {FiltrationTabItem} from "./FiltrationTabItem";

export interface SectionsFiltrationTabs {
  title: string;
  items: FiltrationTabItem[];
}
