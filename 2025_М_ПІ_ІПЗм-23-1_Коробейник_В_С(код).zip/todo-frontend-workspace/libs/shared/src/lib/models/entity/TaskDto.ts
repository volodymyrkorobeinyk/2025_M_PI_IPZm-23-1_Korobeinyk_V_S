export interface TaskDto {
  readonly id: string;
  readonly groupId: string;
  readonly title: string;
  readonly description: string | null;
  readonly isCompleted: boolean;
  readonly completedAt: Date | null;
}
