export interface GroupDto {
  readonly id: string;
  readonly name: string;
  readonly taskCount: number;
}
