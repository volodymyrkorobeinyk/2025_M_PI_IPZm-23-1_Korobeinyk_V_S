import { Pipe, PipeTransform } from '@angular/core';
import {AbstractControl, FormControl} from "@angular/forms";

@Pipe({
  name: 'formControlConvert',
  standalone: true,
  pure: true
})
export class FormControlConvertPipe implements PipeTransform {

  transform(value: AbstractControl): FormControl {
    return value as FormControl;
  }

}
