import { Pipe, PipeTransform } from '@angular/core';

@Pipe({
  name: 'libSharedEmptyValue',
})
export class EmptyValuePipe implements PipeTransform {
  transform(value: string | null): string {
    return value ? value : 'None';
  }
}
