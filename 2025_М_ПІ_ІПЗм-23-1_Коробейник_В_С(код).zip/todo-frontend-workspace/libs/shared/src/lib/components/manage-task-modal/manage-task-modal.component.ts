import {
  ChangeDetectionStrategy,
  Component,
  EventEmitter,
  inject,
  Input,
  OnChanges,
  OnInit,
  Output,
  SimpleChanges,
} from '@angular/core';
import { CommonModule } from '@angular/common';
import {
  FormBuilder,
  FormGroup,
  ReactiveFormsModule,
  Validators,
} from '@angular/forms';
import { FormControlConvertPipe } from '../../pipes/form-control-convert.pipe';
import {
  BaseSelectOption,
  CreateTaskRequestDto,
  GroupDto,
  TaskDto,
  UpdateTaskForm,
} from '../../models';
import { BaseModalComponent } from '../ui/base-modal/base-modal.component';
import { BaseButtonComponent } from '../ui/base-button/base-button.component';
import { BaseInputComponent } from '../ui/base-input/base-input.component';
import { BaseInputLabelComponent } from '../ui/base-input-label/base-input-label.component';
import { BaseTextareaComponent } from '../ui/base-textarea/base-textarea.component';
import { BaseSelectComponent } from '../ui/base-select/base-select.component';
import * as _ from 'lodash';

@Component({
  selector: 'lib-shared-manage-task-modal',
  imports: [
    CommonModule,
    BaseModalComponent,
    ReactiveFormsModule,
    BaseButtonComponent,
    BaseInputComponent,
    BaseInputLabelComponent,
    FormControlConvertPipe,
    BaseTextareaComponent,
    BaseSelectComponent,
  ],
  templateUrl: './manage-task-modal.component.html',
  styleUrl: './manage-task-modal.component.scss',
  changeDetection: ChangeDetectionStrategy.OnPush,
})
export class ManageTaskModalComponent implements OnInit, OnChanges {
  @Input()
  public isOpen = false;

  @Input()
  public task: TaskDto | null = null;

  @Input()
  public groups: BaseSelectOption[] = [];

  @Input()
  public selectedGroup: GroupDto | null = null;

  @Input()
  public inProgress = false;

  @Output()
  public formSubmitted = new EventEmitter<
    CreateTaskRequestDto | UpdateTaskForm
  >();

  @Output()
  public closeModal: EventEmitter<void> = new EventEmitter<void>();

  public get textButton(): string {
    return this.task ? 'Save' : 'Create';
  }

  public get title(): string {
    return this.task ? 'Edit task' : 'Create task';
  }

  public get subtitle(): string {
    return this.task
      ? 'Use the form to edit task'
      : 'Fill in the form to create a new task';
  }

  public taskFrom: FormGroup;
  public formIsChanged = false;

  private readonly fb = inject(FormBuilder);

  public ngOnInit(): void {
    this.initForm();

    if (this.selectedGroup) {
      this.taskFrom?.patchValue({ groupId: this.selectedGroup?.id });
    }
  }

  public ngOnChanges(changes: SimpleChanges): void {
    if (changes['selectedGroup']) {
      this.taskFrom?.patchValue({ groupId: this.selectedGroup?.id });
    }

    if (changes['task']) {
      if (this.task) {
        this.taskFrom.patchValue(this.task);
        this.subscribeToFormChanges();
      }
    }

    if (
      changes['inProgress'] &&
      this.isOpen &&
      !changes['inProgress'].isFirstChange() &&
      !this.inProgress
    ) {
      this.onCloseModal();
    }
  }

  private subscribeToFormChanges(): void {
    this.taskFrom.valueChanges.subscribe(() => {
      const initialTask = {
        title: this.task?.title,
        description: this.task?.description,
        groupId: this.task?.groupId,
      };
      this.formIsChanged = !_.isEqual(initialTask, this.taskFrom.value);
    });
  }

  private initForm(): void {
    this.taskFrom = this.fb.group({
      groupId: ['', Validators.required],
      title: ['', Validators.required],
      description: [''],
    });
  }

  public onCloseModal(): void {
    this.closeModal.emit();
    this.taskFrom.reset();
  }

  public onSelectGroup(groupId: string): void {
    this.taskFrom.patchValue({ groupId });
  }

  public onSubmit(): void {
    if (this.taskFrom.invalid) return;

    const payload = this.task
      ? { id: this.task.id, task: this.taskFrom.value }
      : this.taskFrom.value;

    this.formSubmitted.emit(payload);
  }
}
