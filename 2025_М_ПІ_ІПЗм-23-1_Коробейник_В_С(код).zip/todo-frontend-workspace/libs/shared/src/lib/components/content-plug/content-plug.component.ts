import { Component } from '@angular/core';
import { CommonModule } from '@angular/common';
import {LucideAngularModule} from "lucide-angular";

@Component({
  selector: 'lib-shared-content-plug',
  imports: [CommonModule, LucideAngularModule],
  templateUrl: './content-plug.component.html',
  styleUrl: './content-plug.component.scss',
})
export class ContentPlugComponent {}
