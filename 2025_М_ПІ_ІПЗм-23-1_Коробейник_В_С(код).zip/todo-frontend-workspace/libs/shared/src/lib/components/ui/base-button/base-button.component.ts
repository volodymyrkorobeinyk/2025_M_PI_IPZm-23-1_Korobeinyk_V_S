import { Component, EventEmitter, Input, Output } from '@angular/core';
import { LucideAngularModule } from 'lucide-angular';
import {
  MatProgressSpinner,
  MatProgressSpinnerModule,
} from '@angular/material/progress-spinner';

@Component({
  selector: 'lib-shared-base-button',
  templateUrl: './base-button.component.html',
  styleUrl: './base-button.component.scss',
  imports: [MatProgressSpinnerModule, LucideAngularModule, MatProgressSpinner],
  standalone: true,
})
export class BaseButtonComponent {
  @Input() className: string = '';
  @Input() disabled: boolean | null = false;
  @Input() type: string = 'button';
  @Input() variant: string = 'default';
  @Input() isFailed: boolean = false;
  @Input() inProgress: boolean | null = false;

  // eslint-disable-next-line @angular-eslint/no-output-on-prefix
  @Output() onClick: EventEmitter<MouseEvent> = new EventEmitter<MouseEvent>();

  getButtonClasses(): string {
    switch (this.variant) {
      case 'default':
        return 'bg-[#0068ff] text-white hover:bg-[#0068ff]/90 ';
      case 'outline':
        return 'bg-transparent border border-input hover:bg-[hsl(210,40%,96.1%)] hover:text-[hsl(222.2,47.4%,11.2%)]';
      case 'add':
        return 'bg-transparent border-[2px] border-dashed border-[#1665FF] text-[#1665FF] hover:bg-[hsl(210,40%,96.1%)] hover:text-[hsl(222.2,47.4%,11.2%)]';
      default:
        return 'bg-[#0068ff] text-white hover:bg-[#0068ff]/90 ';
    }
  }

  public handleClick(event: MouseEvent): void {
    if (this.disabled || this.inProgress) {
      return;
    }
    this.onClick.emit(event);
  }
}
