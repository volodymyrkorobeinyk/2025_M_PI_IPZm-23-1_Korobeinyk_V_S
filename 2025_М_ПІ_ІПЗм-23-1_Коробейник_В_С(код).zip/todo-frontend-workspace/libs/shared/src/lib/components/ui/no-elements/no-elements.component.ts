import {Component, Input} from '@angular/core';
import { CommonModule } from '@angular/common';
import {LucideAngularModule} from "lucide-angular";

@Component({
  selector: 'lib-shared-no-elements',
  imports: [CommonModule, LucideAngularModule],
  templateUrl: './no-elements.component.html',
  styleUrl: './no-elements.component.scss',
})
export class NoElementsComponent {
  @Input() icon: string | null = null;
  @Input() isLucideIcon = false;
  @Input() lucideIcon: string = '';
  @Input() lucideIconColor: string = '';
  @Input() lucideIconSize: number = 0;
  @Input() text: string = '';
  @Input() subTitle: string | null = null;
  @Input() iconWidth: number = 50;
  @Input() iconHeight: number = 50;
}
