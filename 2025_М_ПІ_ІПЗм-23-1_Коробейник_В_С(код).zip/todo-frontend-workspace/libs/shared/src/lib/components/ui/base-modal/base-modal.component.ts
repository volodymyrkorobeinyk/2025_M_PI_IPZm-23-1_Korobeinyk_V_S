import {Component, ElementRef, EventEmitter, Input, Output, ViewChild} from '@angular/core';
import {NgIf} from '@angular/common';

@Component({
  selector: 'lib-shared-base-modal',
  templateUrl: './base-modal.component.html',
  styleUrls: ['./base-modal.component.scss'],
  imports: [NgIf],
  standalone: true
})
export class BaseModalComponent {
  @Input() isOpen: boolean = false;
  @Input() formName?: string;
  @Input() subtitle?: string;
  @Input() className?: string;
  @Input() modalBlockClassName?: string;

  @Output() closeModal: EventEmitter<void> = new EventEmitter<void>();

  @ViewChild('modalOverlayRef') modalOverlayRef!: ElementRef;

  modalOverlayHandler(event: MouseEvent): void {
    if (event.target === this.modalOverlayRef?.nativeElement) {
      this.closeModalHandler();
    }
  }

  closeModalHandler() {
    this.closeModal.emit();
  }
}

