import { Component } from '@angular/core';
import { CommonModule } from '@angular/common';

@Component({
  selector: 'lib-shared-base-logo',
  imports: [CommonModule],
  templateUrl: './base-logo.component.html',
  styleUrl: './base-logo.component.scss',
})
export class BaseLogoComponent {}
