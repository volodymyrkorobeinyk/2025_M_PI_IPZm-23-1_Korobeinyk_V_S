import {
  AfterViewInit,
  Component,
  ElementRef,
  EventEmitter,
  forwardRef,
  Input,
  Output,
  ViewChild,
} from '@angular/core';
import {
  FormsModule,
  NG_VALUE_ACCESSOR,
  ReactiveFormsModule,
} from '@angular/forms';

/** Directives */
import { ControlValueAccessorDirective } from '../../../directives/control-value-accessor.directive';
import { NgClass } from '@angular/common';

type InputType =
  | 'text'
  | 'number'
  | 'email'
  | 'password'
  | 'datetime-local'
  | 'datetime'
  | 'date';

@Component({
  selector: 'lib-shared-base-input',
  templateUrl: './base-input.component.html',
  standalone: true,
  imports: [ReactiveFormsModule, FormsModule, NgClass],
  providers: [
    {
      provide: NG_VALUE_ACCESSOR,
      useExisting: forwardRef(() => BaseInputComponent),
      multi: true,
    },
  ],
})
export class BaseInputComponent<T>
  extends ControlValueAccessorDirective<T>
  implements AfterViewInit
{
  @Input() className: string = '';
  @Input() type: InputType = 'text';
  @Input() maxlength: number = 5;
  @Input() id: string = '';
  @Input() disabled: boolean = false;
  @Input() placeholder?: string = '';
  @Input() value: string | number = '';
  @Input() min: number = 0;
  @Input() isReadonly: boolean = false;
  @Input() errorMessage: string;
  @Input() isWithoutControls: boolean = false;
  @Input() isFocused: boolean = false;

  @Output() valueChanged = new EventEmitter<string>();
  @Output() keyUp: EventEmitter<KeyboardEvent> =
    new EventEmitter<KeyboardEvent>();
  @Output() click: EventEmitter<Event> = new EventEmitter<Event>();
  @Output() blur: EventEmitter<FocusEvent> = new EventEmitter<FocusEvent>();
  @Output() enterPressed: EventEmitter<void> = new EventEmitter<void>();

  @ViewChild('inputElement', { static: true }) inputElement: ElementRef;

  ngAfterViewInit() {
    if (this.isFocused) {
      this.focus();
    }
  }

  public keyUpHandler(event: KeyboardEvent): void {
    this.keyUp.emit(event);
    if (event.key === 'Enter') {
      this.enterPressed.emit();
    }
  }

  public onInput(event: Event) {
    const inputValue = (event.target as HTMLInputElement).value;
    this.valueChanged.emit(inputValue);
  }

  public onBlur(event: FocusEvent) {
    this.blur.emit(event);
  }

  public onEnterPressed() {
    this.enterPressed.emit();
  }

  public clearInput() {
    this.value = '';
    this.valueChanged.emit('');
  }

  public focus() {
    this.inputElement.nativeElement.focus();
  }
}
