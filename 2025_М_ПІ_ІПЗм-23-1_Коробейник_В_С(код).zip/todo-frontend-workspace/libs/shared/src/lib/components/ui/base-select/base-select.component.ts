import {
  Component,
  ElementRef,
  EventEmitter,
  forwardRef,
  HostListener,
  inject,
  Input,
  OnChanges,
  OnInit,
  Output,
  SimpleChanges,
} from '@angular/core';
import { NgClass, NgStyle } from '@angular/common';
import { NG_VALUE_ACCESSOR } from '@angular/forms';
import { ControlValueAccessorDirective } from '../../../directives/control-value-accessor.directive';
import {BaseSelectOption} from "../../../models/BaseSelectOption";


@Component({
  selector: 'lib-shared-base-select',
  templateUrl: './base-select.component.html',
  imports: [NgStyle, NgClass],
  providers: [
    {
      provide: NG_VALUE_ACCESSOR,
      useExisting: forwardRef(() => BaseSelectComponent),
      multi: true,
    },
  ],
})
export class BaseSelectComponent<T>
  extends ControlValueAccessorDirective<T>
  implements OnInit, OnChanges
{
  @Input()
  public className: string = '';

  @Input()
  public options: BaseSelectOption[] = [];

  @Input()
  public placeholder: string = 'Select Option';

  @Input()
  public defaultSelected: any | null = null;

  @Input()
  public arrowSize: number = 24;

  @Input() errorMessage: string;

  @Output()
  public optionSelected: EventEmitter<any> = new EventEmitter<any>();

  public selectedOption: any | null = null;
  public isOpen = false;

  private readonly elementRef = inject(ElementRef);

  override ngOnInit() {
    super.ngOnInit();
    this.selectedOption = this.options.find(
      (option) => option.value === this.defaultSelected
    );
  }

  ngOnChanges(changes: SimpleChanges): void {
    if (changes['options']) {
      this.selectedOption = this.options.find(
        (option) => option.value === this.defaultSelected
      );
    }
    if (changes['defaultSelected']) {
      this.selectedOption = this.options.find(
        (option) => option.value === this.defaultSelected
      );
    }
  }

  @HostListener('document:click', ['$event'])
  public onClick(event: MouseEvent): void {
    if (!this.elementRef.nativeElement.contains(event.target)) {
      this.isOpen = false;
    }
  }

  public toggleSelect(): void {
    this.isOpen = !this.isOpen;
  }

  public onOptionSelect(event: Event, option: any): void {
    event.stopPropagation();
    this.selectedOption = option;
    this.optionSelected.emit(option.value);
    this.isOpen = false;
  }
}
