import { Component, EventEmitter, Input, Output } from '@angular/core';
import { FormsModule } from "@angular/forms";
import { NgStyle } from "@angular/common";
import { Subject, debounceTime } from 'rxjs';

@Component({
  selector: 'lib-shared-search-input',
  templateUrl: './search-input.component.html',
  styleUrls: ['./search-input.component.scss'],
  imports: [NgStyle, FormsModule],
  standalone: true
})
export class SearchInputComponent {
  @Input() placeholder: string;
  @Input() searchValue = '';
  @Input() inputClass: string;
  @Input() containerClass: string;
  @Input() debounceTime = 200;
  @Output() valueChanged = new EventEmitter<string>();

  value: string = this.searchValue;
  isFocused = false;

  private inputSubject = new Subject<string>();

  constructor() {
    this.inputSubject
      .pipe(debounceTime(this.debounceTime))
      .subscribe((value) => {
        this.valueChanged.emit(value);
      });
  }

  onFocus() {
    this.isFocused = true;
  }

  onBlur() {
    this.isFocused = false;
  }

  onInput() {
    this.inputSubject.next(this.value);
  }

  clearInput() {
    this.value = '';
    this.inputSubject.next(this.value);
  }
}
