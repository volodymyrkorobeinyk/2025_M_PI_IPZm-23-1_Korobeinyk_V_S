import {Component, Input} from '@angular/core';

@Component({
  selector: 'lib-shared-base-input-label',
  templateUrl: './base-input-label.component.html',
  styleUrls: ['./base-input-label.component.scss'],
  standalone: true
})

export class BaseInputLabelComponent {
  @Input() className: string = '';
  @Input() isRequired: boolean = false;
  @Input() labelText: string = '';
  @Input() additionalText: string = '';
  @Input() inputId: string = '';
}
