import {AfterViewInit, Component, ElementRef, EventEmitter, forwardRef, Input, Output, ViewChild} from '@angular/core';
import {NG_VALUE_ACCESSOR, ReactiveFormsModule} from "@angular/forms";
import {ControlValueAccessorDirective} from "../../../directives/control-value-accessor.directive";

/** Directives */

@Component({
    selector: 'lib-shared-base-textarea',
    templateUrl: './base-textarea.component.html',
  imports: [ReactiveFormsModule],
    providers: [
        {
            provide: NG_VALUE_ACCESSOR,
            useExisting: forwardRef(() => BaseTextareaComponent),
            multi: true,
        },
    ]
})
export class BaseTextareaComponent<T> extends ControlValueAccessorDirective<T> implements AfterViewInit  {
  @Input() className: string = '';
  @Input() id: string = '';
  @Input() disabled: boolean = false;
  @Input() placeholder: string = '';
  @Input() value: string = '';
  @Input() isReadonly: boolean = false;
  @Input() isFocused: boolean = false;

  @ViewChild('textArea', { static: false }) textArea: ElementRef<HTMLTextAreaElement>;

  @Output() keyUp: EventEmitter<KeyboardEvent> = new EventEmitter<KeyboardEvent>();
  @Output() click: EventEmitter<Event> = new EventEmitter<Event>();
  @Output() blur: EventEmitter<Event> = new EventEmitter<Event>();
  @Output() enterPressed: EventEmitter<void> = new EventEmitter<void>();

  ngAfterViewInit() {
    if (this.isFocused) {
      this.focusOnTextArea();
    }
  }

  public keyUpHandler(event: KeyboardEvent): void {
    this.keyUp.emit(event);
    if (event.key === 'Enter') {
      this.enterPressed.emit();
    }
  }

  public blurHandler(event: Event): void {
    this.blur.emit(event);
  }

  public focusOnTextArea(): void {
    this.textArea.nativeElement.focus();
  }
}
