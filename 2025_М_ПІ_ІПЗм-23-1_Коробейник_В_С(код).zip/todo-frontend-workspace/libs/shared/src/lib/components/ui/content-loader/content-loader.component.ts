import {Component, Input} from '@angular/core';
import { CommonModule } from '@angular/common';

@Component({
  selector: 'lib-shared-content-loader',
  imports: [CommonModule],
  templateUrl: './content-loader.component.html',
  styleUrl: './content-loader.component.scss',
})
export class ContentLoaderComponent {
  @Input() className: string = '';
}
