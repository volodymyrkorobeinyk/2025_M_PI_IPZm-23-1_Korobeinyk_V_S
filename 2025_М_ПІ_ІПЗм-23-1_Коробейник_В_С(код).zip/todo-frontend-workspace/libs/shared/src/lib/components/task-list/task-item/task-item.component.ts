import {Component, EventEmitter, Input, Output} from '@angular/core';
import { CommonModule } from '@angular/common';
import {LucideAngularModule} from "lucide-angular";
import {EmptyValuePipe} from "../../../pipes/empty-value.pipe";
import {TaskDto} from "../../../models/entity/TaskDto";

@Component({
  selector: 'lib-shared-task-item',
  imports: [CommonModule, EmptyValuePipe, LucideAngularModule],
  templateUrl: './task-item.component.html',
  styleUrl: './task-item.component.scss',
})
export class TaskItemComponent {
  @Input()
  public task: TaskDto;

  @Output()
  public deleteTask = new EventEmitter<string>();

  @Output()
  public toggleTaskCompletion = new EventEmitter<TaskDto>();

  @Output()
  public editTask = new EventEmitter<TaskDto>();

  public isExpanded = false;

  public toggleDescription(): void {
    this.isExpanded = !this.isExpanded;
  }

  public onTaskToggleCompletion(): void {
    this.toggleTaskCompletion.emit(this.task);
  }

  public onTaskEdit(): void {
    this.editTask.emit(this.task);
  }

  public onTaskDelete(): void {
    this.deleteTask.emit(this.task.id);
  }
}
