import {
  ChangeDetectionStrategy,
  Component,
  EventEmitter,
  Input,
  Output,
} from '@angular/core';
import { CommonModule } from '@angular/common';
import { ContentLoaderComponent } from '../ui/content-loader/content-loader.component';

import { TaskDto } from '../../models/entity/TaskDto';
import { Observable } from 'rxjs';
import { NoElementsComponent } from '../ui/no-elements/no-elements.component';
import { LucideAngularModule } from 'lucide-angular';
import { TaskItemComponent } from './task-item/task-item.component';

@Component({
  selector: 'lib-shared-task-list',
  imports: [
    CommonModule,
    ContentLoaderComponent,
    NoElementsComponent,
    LucideAngularModule,
    TaskItemComponent,
  ],
  templateUrl: './task-list.component.html',
  styleUrl: './task-list.component.scss',
  changeDetection: ChangeDetectionStrategy.OnPush,
})
export class TaskListComponent {
  @Input()
  public tasks$: Observable<TaskDto[] | null>;

  @Output()
  public deleteTask = new EventEmitter<string>();

  @Output()
  public toggleTaskCompletion = new EventEmitter<TaskDto>();

  @Output()
  public editTask = new EventEmitter<TaskDto>();

  public onTaskDelete(id: string): void {
    this.deleteTask.emit(id);
  }

  public onTaskToggleCompletion(task: TaskDto): void {
    this.toggleTaskCompletion.emit(task);
  }

  public onTaskEdit(task: TaskDto): void {
    this.editTask.emit(task);
  }
}
