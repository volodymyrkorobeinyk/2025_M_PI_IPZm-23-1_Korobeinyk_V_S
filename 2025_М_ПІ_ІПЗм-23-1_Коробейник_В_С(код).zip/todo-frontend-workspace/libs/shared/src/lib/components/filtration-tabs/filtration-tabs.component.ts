import {Component, EventEmitter, Input, Output} from '@angular/core';
import { CommonModule } from '@angular/common';
import {LucideAngularModule} from "lucide-angular";
import {SectionsFiltrationTabs} from "../../models/SectionsFiltrationTabs";
import {FiltrationTabItem} from "../../models/FiltrationTabItem";

@Component({
  selector: 'lib-shared-filtration-tabs',
  imports: [CommonModule, LucideAngularModule],
  templateUrl: './filtration-tabs.component.html',
  styleUrl: './filtration-tabs.component.scss',
})
export class FiltrationTabsComponent {
  @Input()
  public sections: SectionsFiltrationTabs[] = [];

  @Input()
  public selectedType: any;

  @Output()
  public tabChange = new EventEmitter<any>();

  public onItemClick(item: FiltrationTabItem): void {
    this.tabChange.emit(item.type);
  }
}
