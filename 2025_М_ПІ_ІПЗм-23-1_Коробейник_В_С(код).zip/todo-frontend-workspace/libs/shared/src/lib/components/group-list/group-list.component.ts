import {Component, EventEmitter, HostListener, Input, Output} from '@angular/core';
import { CommonModule } from '@angular/common';
import { LucideAngularModule } from 'lucide-angular';
import { GroupDto } from '../../models/entity/GroupDto';
import { Observable } from 'rxjs';
import { ContentLoaderComponent } from '../ui/content-loader/content-loader.component';
import { NoElementsComponent } from '../ui/no-elements/no-elements.component';
import { TruncatePipe } from '../../pipes/truncate.pipe';
import { BaseButtonComponent } from '../ui/base-button/base-button.component';

@Component({
  selector: 'lib-shared-group-list',
  imports: [
    CommonModule,
    LucideAngularModule,
    ContentLoaderComponent,
    NoElementsComponent,
    TruncatePipe,
    BaseButtonComponent,
  ],
  templateUrl: './group-list.component.html',
  styleUrl: './group-list.component.scss',
})
export class GroupListComponent {
  @Input()
  public groups$: Observable<GroupDto[] | null>;

  @Input()
  public selectedGroup: GroupDto | null;

  @Output()
  public groupChange = new EventEmitter<GroupDto>();

  @Output()
  public addGroup = new EventEmitter<void>();

  @Output()
  public editGroup = new EventEmitter<GroupDto>();

  @Output()
  public deleteGroup = new EventEmitter<string>();

  public contextMenuVisible: boolean = false;
  public contextMenuX: number = 0;
  public contextMenuY: number = 0;
  public selectedContextGroup: GroupDto | null = null;

  @HostListener('document:click', ['$event'])
  public onDocumentClick(event: MouseEvent): void {
    if (this.contextMenuVisible) {
      this.closeContextMenu();
    }
  }

  @HostListener('window:scroll')
  public onWindowScroll(): void {
    this.closeContextMenu();
  }

  public onItemClick(group: GroupDto): void {
    this.groupChange.emit(group);
  }

  public onRightClick(event: MouseEvent, group: GroupDto): void {
    event.preventDefault();

    this.selectedContextGroup = group;
    this.contextMenuVisible = true;
    this.contextMenuX = event.clientX;
    this.contextMenuY = event.clientY;
  }

  public editItem(): void {
    this.editGroup.emit(this.selectedContextGroup!);
    this.closeContextMenu();
  }

  public deleteItem(): void {
    this.deleteGroup.emit(this.selectedContextGroup?.id);
    this.closeContextMenu();
  }

  private closeContextMenu(): void {
    this.contextMenuVisible = false;
    this.selectedContextGroup = null;
  }

  public addItem(): void {
    this.addGroup.emit();
  }
}
