import {
  Component,
  EventEmitter,
  inject,
  Input, OnChanges,
  OnInit,
  Output, SimpleChanges,
} from '@angular/core';
import { CommonModule } from '@angular/common';
import { BaseModalComponent } from '../ui/base-modal/base-modal.component';
import {FormBuilder, FormGroup, ReactiveFormsModule, Validators} from '@angular/forms';
import { GroupDto, UpdateGroupFrom, CreateGroupRequestDto } from '../../models';
import {FormControlConvertPipe} from "../../pipes/form-control-convert.pipe";
import {BaseInputLabelComponent} from "../ui/base-input-label/base-input-label.component";
import {BaseInputComponent} from "../ui/base-input/base-input.component";
import {BaseButtonComponent} from "../ui/base-button/base-button.component";
import {finalize, Observable} from "rxjs";

@Component({
  selector: 'lib-shared-manage-group-modal',
  imports: [
    CommonModule,
    BaseModalComponent,
    BaseInputLabelComponent,
    BaseInputComponent,
    FormControlConvertPipe,
    ReactiveFormsModule,
    BaseButtonComponent,
  ],
  templateUrl: './manage-group-modal.component.html',
  styleUrl: './manage-group-modal.component.scss',
})
export class ManageGroupModalComponent implements OnInit, OnChanges {
  @Input()
  public isOpen = false;

  @Input()
  public group: GroupDto | null = null;

  @Input()
  public inProgress = false;

  @Output()
  public formSubmitted = new EventEmitter<CreateGroupRequestDto | UpdateGroupFrom>();

  @Output()
  public closeModal: EventEmitter<void> = new EventEmitter<void>();

  public groupForm: FormGroup;
  public formIsChanged = false;

  public get textButton(): string {
    return this.group ? 'Save' : 'Create';
  }

  public get title(): string {
    return this.group ? 'Edit group' : 'Create group';
  }

  public get subtitle(): string {
    return this.group ? 'Use the form to edit group' : 'Fill in the form to create a new group';
  }

  private readonly fb = inject(FormBuilder);

  public ngOnInit(): void {
    this.initForm();
  }

  public ngOnChanges(changes: SimpleChanges): void {
    if (changes['group']) {
      if (this.group) {
        this.fillForm();
        this.subscribeToFormChanges();
      }
    }

    if (changes['inProgress'] && this.isOpen &&
      !(changes['inProgress'].isFirstChange()) && !this.inProgress) {
      this.onCloseModal();
    }
  }

  private fillForm(): void {
    const name = this.group?.name;
    this.groupForm.patchValue({name});
  }

  private subscribeToFormChanges(): void {
    this.groupForm.valueChanges.subscribe(() => {
      this.formIsChanged = this.group?.name !== this.groupForm.value.name;
    });
  }

  private initForm(): void {
    this.groupForm = this.fb.group({
      name: ['', Validators.required],
    });
  }

  public onCloseModal(): void {
    this.closeModal.emit();
    this.groupForm.reset();
  }

  public onSubmit(): void {
    if (this.groupForm.invalid) return;

    const payload = this.group
      ? { id: this.group.id, group: this.groupForm.value }
      : { name: this.groupForm.value.name };

    this.formSubmitted.emit(payload);
  }
}
