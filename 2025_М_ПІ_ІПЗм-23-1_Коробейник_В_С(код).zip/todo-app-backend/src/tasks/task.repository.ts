import {Injectable} from '@nestjs/common';
import {InjectModel} from '@nestjs/sequelize';
import {BaseRepository} from "../core/repositories/base.repository";
import {Task} from "../entities/Task.entity";
import {FilterTaskStatus} from "./types/FilterTaskStatus";

@Injectable()
export class TaskRepository extends BaseRepository<Task> {
    public constructor(
        @InjectModel(Task) taskModel: typeof Task
    ) {
        super(taskModel);
    }

    public async findAllByGroup(groupId: string, filter: FilterTaskStatus): Promise<Task[]> {
        const whereClause: any = { groupId };

        if (filter === FilterTaskStatus.COMPLETED) {
            whereClause.isCompleted = true;
        } else if (filter === FilterTaskStatus.UNCOMPLETED) {
            whereClause.isCompleted = false;
        }

        return this.model.findAll({ where: whereClause });
    }

    public async countAllByGroup(groupId: string): Promise<number> {
        return this.model.count({ where: { groupId } });
    }
}