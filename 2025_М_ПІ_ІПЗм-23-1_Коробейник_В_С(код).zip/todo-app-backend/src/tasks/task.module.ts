import {forwardRef, Module} from '@nestjs/common';
import {TaskController} from './task.controller';
import {TaskService} from './task.service';
import {TaskRepository} from "./task.repository";
import {GroupModule} from "../groups/group.module";
import {SequelizeModule} from "@nestjs/sequelize";
import {Task} from "../entities/Task.entity";

@Module({
    imports: [
        SequelizeModule.forFeature([Task]),
        forwardRef(() => GroupModule)
    ],
    controllers: [TaskController],
    providers: [TaskService, TaskRepository],
    exports: [TaskService]
})
export class TaskModule {
}
