export enum FilterTaskStatus {
    ALL = 'ALL',
    COMPLETED = 'COMPLETED',
    UNCOMPLETED = 'UNCOMPLETED'
}