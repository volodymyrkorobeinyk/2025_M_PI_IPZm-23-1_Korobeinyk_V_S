import {IsNotEmpty, IsString} from "class-validator";

export class UpdateTaskDto {
    @IsString({message: 'Name must be a string'})
    @IsNotEmpty({message: 'Name is required'})
    readonly title: string;

    @IsString({message: 'Name must be a string'})
    readonly description: string;
}