import {Task} from "../../entities/Task.entity";

export class TaskDto {
    readonly id: string;
    readonly groupId: string;
    readonly title: string;
    readonly description: string | null;
    readonly isCompleted: boolean;
    readonly completedAt: Date | null;

    constructor(task: Task) {
        this.id = task.id;
        this.groupId = task.groupId;
        this.title = task.title;
        this.description = task.description;
        this.isCompleted = task.isCompleted;
        this.completedAt = task.completedAt;
    }
}