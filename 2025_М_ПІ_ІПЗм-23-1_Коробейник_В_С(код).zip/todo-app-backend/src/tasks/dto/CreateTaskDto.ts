import {IsNotEmpty, IsOptional, IsString} from "class-validator";

export class CreateTaskDto {
    @IsString({message: 'Group id must be a string'})
    @IsNotEmpty({message: 'Group id is required'})
    readonly groupId: string;

    @IsString({message: 'Name must be a string'})
    @IsNotEmpty({message: 'Name is required'})
    readonly title: string;

    @IsOptional()
    @IsString({message: 'Name must be a string'})
    readonly description?: string;
}