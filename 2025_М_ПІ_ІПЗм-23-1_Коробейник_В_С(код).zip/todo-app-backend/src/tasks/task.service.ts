import {forwardRef, Inject, Injectable} from '@nestjs/common';
import {TaskRepository} from "./task.repository";
import {CreateTaskDto} from "./dto/CreateTaskDto";
import {GroupService} from "../groups/group.service";
import {TaskDto} from "./dto/TaskDto";
import {UpdateTaskDto} from "./dto/UpdateTaskDto";
import {FilterTaskStatus} from "./types/FilterTaskStatus";

@Injectable()
export class TaskService {
    public constructor(
        private readonly taskRepository: TaskRepository,
        @Inject(forwardRef(() => GroupService))
        private readonly groupService: GroupService
    ) {}

    public async getAllByGroup(groupId: string, filter: FilterTaskStatus): Promise<TaskDto[]> {
        if (!await this.checkIfGroupExists(groupId)) {
            throw new Error('Group does not exist');
        }

        const groupsTasks = await this.taskRepository.findAllByGroup(groupId, filter);

        return groupsTasks.map(task => new TaskDto(task));
    }

    public async create(task: CreateTaskDto): Promise<TaskDto> {
        if (!await this.checkIfGroupExists(task.groupId)) {
            throw new Error('Group does not exist');
        }

        const createdTask = await this.taskRepository.create(task);

        return new TaskDto(createdTask);
    }

    public async update(id: string, task: UpdateTaskDto): Promise<TaskDto> {
        const existingTask = await this.taskRepository.findById(id);

        if (existingTask === null) throw new Error('Task does not exist');

        const updatedTask = await this.taskRepository.update(id, task);

        return new TaskDto(updatedTask);
    }

    public async completeTask(id: string): Promise<TaskDto> {
        const task = await this.taskRepository.findById(id);

        if (task === null) throw new Error('Task does not exist');

        task.completedAt = task.isCompleted ? null : new Date();
        task.isCompleted = !task.isCompleted;

        await task.save();

        return new TaskDto(task);
    }

    public async delete(id: string): Promise<boolean> {
        const task = await this.taskRepository.findById(id);

        if (task === null) throw new Error('Task does not exist');

        return this.taskRepository.delete(id);
    }

    public async getCountTaskByGroupId(id: string): Promise<number> {
        return await this.taskRepository.countAllByGroup(id);
    }

    private async checkIfGroupExists(groupId: string): Promise<boolean> {
        return await this.groupService.getById(groupId) !== null;
    }
}
