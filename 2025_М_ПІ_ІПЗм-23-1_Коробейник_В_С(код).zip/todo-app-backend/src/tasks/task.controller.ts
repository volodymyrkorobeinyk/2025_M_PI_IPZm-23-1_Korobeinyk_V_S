import {Body, Controller, Delete, Get, Param, Patch, Post, Query} from '@nestjs/common';
import {TaskService} from "./task.service";
import {CreateTaskDto} from "./dto/CreateTaskDto";
import {TaskDto} from "./dto/TaskDto";
import {UpdateTaskDto} from "./dto/UpdateTaskDto";
import {FilterTaskStatus} from "./types/FilterTaskStatus";

@Controller('tasks')
export class TaskController {
    public constructor(
        private readonly taskService: TaskService
    ) {}
к
    @Get(':id')
    public async getAllByGroup(
        @Param('id') groupId: string,
        @Query('filter') filter: FilterTaskStatus = FilterTaskStatus.ALL
    ): Promise<TaskDto[]> {
        console.log(filter)
        return this.taskService.getAllByGroup(groupId, filter);
    }

    @Post()
    public async create(@Body() createTaskDto: CreateTaskDto): Promise<TaskDto> {
        return this.taskService.create(createTaskDto);
    }

    @Patch(':id')
    public update(@Param('id') taskId: string, @Body() updateTaskDto: UpdateTaskDto): Promise<TaskDto> {
        return this.taskService.update(taskId, updateTaskDto);
    }

    @Patch('toggleCompletion/:id')
    public async completeTask(@Param('id') taskId: string): Promise<TaskDto> {
        return this.taskService.completeTask(taskId);
    }

    @Delete(':id')
    public async delete(@Param('id') taskId: string): Promise<boolean> {
        return this.taskService.delete(taskId);
    }
}
