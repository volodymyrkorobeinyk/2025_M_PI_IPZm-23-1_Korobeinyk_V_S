import {Module} from '@nestjs/common';
import {SequelizeModule} from "@nestjs/sequelize";
import {GroupModule} from './groups/group.module';
import {ConfigModule} from "@nestjs/config";
import * as process from "node:process";
import {databaseConfig} from "./config/database.config";
import {TaskModule} from "./tasks/task.module";

@Module({
    controllers: [],
    providers: [],
    imports: [
        ConfigModule.forRoot({
            envFilePath: `.${process.env.NODE_ENV}.env`
        }),
        SequelizeModule.forRoot(databaseConfig()),
        GroupModule,
        TaskModule
    ]
})
export class AppModule {}
