import { Column, DataType, Model, Table, ForeignKey, BelongsTo } from "sequelize-typescript";
import { Group } from "./Group.entity";

interface TaskAttributes {
    groupId: string;
    title: string;
    description?: string;
}

@Table({ tableName: 'tasks' })
export class Task extends Model<Task, TaskAttributes> {
    @Column({ type: DataType.UUID, primaryKey: true, defaultValue: DataType.UUIDV4 })
    id: string;

    @ForeignKey(() => Group)
    @Column({ type: DataType.UUID, allowNull: false })
    groupId: string;

    @Column({ type: DataType.STRING, allowNull: false })
    title: string;

    @Column({ type: DataType.TEXT, allowNull: true })
    description: string | null;

    @Column({ type: DataType.DATE, allowNull: true, defaultValue: null })
    completedAt: Date | null;

    @Column({ type: DataType.BOOLEAN, allowNull: false, defaultValue: false })
    isCompleted: boolean;

    @BelongsTo(() => Group)
    group: Group;
}
