import { Column, DataType, Model, Table, HasMany } from "sequelize-typescript";
import { Task } from "./Task.entity";

interface GroupAttributes {
    name: string;
}

@Table({ tableName: 'groups' })
export class Group extends Model<Group, GroupAttributes> {
    @Column({ type: DataType.UUID, primaryKey: true, defaultValue: DataType.UUIDV4 })
    id: string;

    @Column({ type: DataType.STRING, allowNull: false })
    name: string;

    @HasMany(() => Task)
    tasks: Task[];
}