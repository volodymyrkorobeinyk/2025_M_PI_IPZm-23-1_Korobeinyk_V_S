import { Injectable } from '@nestjs/common';
import {
    Model,
    ModelStatic,
    FindOptions,
    CreationAttributes,
    UpdateOptions,
    DestroyOptions
} from 'sequelize';
import { MakeNullishOptional } from 'sequelize/types/utils';

@Injectable()
export abstract class BaseRepository<T extends Model> {
    protected constructor(
        protected readonly model: ModelStatic<T>
    ) {}

    public async findAll(options?: FindOptions): Promise<T[]> {
        return this.model.findAll(options);
    }

    public async findById(id: string): Promise<T | null> {
        return this.model.findByPk(id);
    }

    public async create(data: MakeNullishOptional<CreationAttributes<T>>): Promise<T> {
        return this.model.create(data);
    }

    public async update(id: string, data: Partial<CreationAttributes<T>>): Promise<T> {
        const [affectedCount] = await this.model.update(data, {
            where: { id },
            returning: true
        } as UpdateOptions);

        if (affectedCount === 0) throw new Error('Record not found');
        return this.findById(id) as Promise<T>;
    }

    public async delete(id: string): Promise<boolean> {
        const affectedCount = await this.model.destroy({ where: { id } } as DestroyOptions);
        return affectedCount > 0;
    }
}