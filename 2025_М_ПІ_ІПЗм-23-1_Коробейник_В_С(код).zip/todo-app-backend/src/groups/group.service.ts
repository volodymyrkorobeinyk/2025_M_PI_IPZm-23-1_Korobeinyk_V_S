import {forwardRef, Inject, Injectable} from '@nestjs/common';
import {CreateGroupDto} from "./dto/CreateGroupDto";
import {GroupRepository} from "./group.repository";
import {Group} from "../entities/Group.entity";
import {UpdateGroupDto} from "./dto/UpdateGroupDto";
import {GroupDto} from "./dto/GroupDto";
import {TaskService} from "../tasks/task.service";

@Injectable()
export class GroupService {
    public constructor(
        private readonly groupsRepository: GroupRepository,

        @Inject(forwardRef(() => TaskService))
        private readonly taskService: TaskService
    ) {}

    public async getAll(): Promise<GroupDto[]> {
        const groups = await this.groupsRepository.findAllWithTaskCount();

        return groups.map(group => new GroupDto(group.dataValues));
    }

    public async searchByName(name: string): Promise<GroupDto[]> {
        const groups = await this.groupsRepository.searchByName(name);

        return groups.map(group => new GroupDto(group.dataValues));
    }

    public async create(group: CreateGroupDto): Promise<GroupDto> {
        const createGroup = await this.groupsRepository.create(group);
        return new GroupDto({...createGroup.dataValues, taskCount: 0});
    }

    public async update(id: string, group: UpdateGroupDto): Promise<GroupDto> {
        const taskCount = await this.taskService.getCountTaskByGroupId(id);
        const updatedGroup = await this.groupsRepository.update(id, group);
        return new GroupDto({...updatedGroup.dataValues, taskCount});
    }

    public async delete(id: string): Promise<boolean> {
        return this.groupsRepository.delete(id);
    }

    public async getById(id: string): Promise<Group | null> {
        return this.groupsRepository.findById(id);
    }
}
