import {Body, Controller, Delete, Get, Param, Patch, Post, Query} from '@nestjs/common';
import {GroupService} from "./group.service";
import {CreateGroupDto} from "./dto/CreateGroupDto";
import {UpdateGroupDto} from "./dto/UpdateGroupDto";
import {GroupDto} from "./dto/GroupDto";

@Controller('groups')
export class GroupController {

    public constructor(
        private readonly groupsService: GroupService
    ) {}

    @Get()
    public getAll(): Promise<GroupDto[]> {
        return this.groupsService.getAll();
    }

    @Get('/search')
    public search(@Query('name') name?: string): Promise<GroupDto[]> {
        return this.groupsService.searchByName(name ?? '');
    }

    @Post()
    public create(@Body() createGroupDto: CreateGroupDto): Promise<GroupDto> {
        return this.groupsService.create(createGroupDto);
    }

    @Patch(':id')
    public update(
        @Param('id') id: string,
        @Body() updateGroupDto: UpdateGroupDto
    ): Promise<GroupDto> {
        return this.groupsService.update(id, updateGroupDto);
    }

    @Delete(':id')
    public delete(@Param('id') id: string): Promise<boolean> {
        return this.groupsService.delete(id);
    }
}
