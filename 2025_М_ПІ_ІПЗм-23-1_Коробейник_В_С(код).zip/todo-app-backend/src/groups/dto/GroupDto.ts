export class GroupDto {
    readonly id: string;
    readonly name: string;
    readonly taskCount: number;

    constructor(group: any) {
        this.id = group.id;
        this.name = group.name;
        this.taskCount = group.taskCount;
    }
}