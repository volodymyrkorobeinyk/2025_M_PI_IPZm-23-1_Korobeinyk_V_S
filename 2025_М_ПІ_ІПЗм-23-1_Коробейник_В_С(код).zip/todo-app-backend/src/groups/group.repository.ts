import { Injectable } from '@nestjs/common';
import { InjectModel } from '@nestjs/sequelize';
import {BaseRepository} from "../core/repositories/base.repository";
import {Group} from "../entities/Group.entity";
import {Op, Sequelize} from "sequelize";
import {Task} from "../entities/Task.entity";

@Injectable()
export class GroupRepository extends BaseRepository<Group> {
    public constructor(
        @InjectModel(Group) groupModel: typeof Group
    ) {
        super(groupModel);
    }

    public async searchByName(name: string): Promise<Group[]> {
        return this.model.findAll({
            attributes: [
                'id',
                'name',
                [Sequelize.fn('COALESCE', Sequelize.fn('COUNT', Sequelize.col('tasks.id')), 0), 'taskCount']
            ],
            include: [
                {
                    model: Task,
                    attributes: [],
                    required: false,
                },
            ],
            group: ['Group.id'],
            where: {
                name: {
                    [Op.iLike]: `%${name}%`
                }
            }
        });
    }

    public async findAllWithTaskCount(): Promise<Group[]> {
        return this.model.findAll({
            attributes: [
                'id',
                'name',
                [Sequelize.fn('COALESCE', Sequelize.fn('COUNT', Sequelize.col('tasks.id')), 0), 'taskCount']
            ],
            include: [
                {
                    model: Task,
                    attributes: [],
                    required: false,
                },
            ],
            group: ['Group.id'],
        });
    }
}